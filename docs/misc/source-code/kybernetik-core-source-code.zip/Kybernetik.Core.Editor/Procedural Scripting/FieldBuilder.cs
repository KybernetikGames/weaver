﻿// Kybernetik // Copyright 2019 Kybernetik //

#if PROCEDURAL_SCRIPTING

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using UnityEngine;

namespace Kybernetik.ProceduralScripting
{
    /// <summary>
    /// Manages the details for building a field in a procedural C# script.
    /// </summary>
    public class FieldBuilder : MemberBuilder
    {
        /************************************************************************************************************************/
        #region Fields and Properties
        /************************************************************************************************************************/

        /// <summary>
        /// The type of object this field holds. Corresponds to <see cref="FieldInfo.FieldType"/>.
        /// </summary>
        public Type FieldType { get; private set; }

        /// <summary>
        /// The initial value of the field.
        /// </summary>
        public object Value { get; private set; }

        /// <summary>
        /// If set to true, the field type will be given a "global::" prefix to avoid type naming conflicts.
        /// </summary>
        public bool UseGlobalFieldTypeName { get; set; }

        /// <summary>
        /// Used to check if the specified <see cref="object"/> is equal to the <see cref="Value"/> of this field when
        /// determining if the script needs to be rebuilt. If null, the check will be skipped.
        /// </summary>
        public Func<object, bool> ValueEquals { get; set; }

        /************************************************************************************************************************/

        /// <summary>
        /// A delegate used to append the initialiser for a field.
        /// </summary>
        public delegate void AppendInitialiserMethod(StringBuilder text, int indent, object value);

        /// <summary>
        /// A method which takes the following parameters and appends an appropriate field initialiser:
        /// (<see cref="StringBuilder"/> text, <see cref="int"/> indent, <see cref="object"/> value).
        /// <para></para>
        /// By default, <see cref="CSharp.GetInitialiser(object)"/> will be used.
        /// <para></para>
        /// Note that this delegate is called immediately after the field name and before the semicolon, so it must
        /// begin with " = " to assign a value and should not append a semicolon at the end.
        /// </summary>
        public AppendInitialiserMethod AppendInitialiser { get; set; }

        /************************************************************************************************************************/

        /// <summary>
        /// The <see cref="FieldInfo"/> of the field with the same type and name as this builder.
        /// This property is gathered by <see cref="IsExistingMember(MemberInfo, ref bool)"/>.
        /// </summary>
        public FieldInfo ExistingField { get; private set; }

        /// <summary>
        /// The <see cref="FieldInfo"/> of the field with the same type and name as this builder.
        /// This property is gathered by <see cref="IsExistingMember(MemberInfo, ref bool)"/>.
        /// </summary>
        public override MemberInfo ExistingMember => ExistingField;

        /************************************************************************************************************************/

        /// <summary>This is a <see cref="MemberTypes.Field"/>.</summary>
        public override MemberTypes MemberType => MemberTypes.Field;

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Pooling
        /************************************************************************************************************************/

        private static readonly List<FieldBuilder> Pool = new List<FieldBuilder>();

        /************************************************************************************************************************/

        /// <summary>
        /// Get a <see cref="FieldBuilder"/> from the object pool and initialise it with the specified parameters.
        /// </summary>
        public static FieldBuilder Get(TypeBuilder declaringType, string nameSource, Type fieldType, object value)
        {
            var field = Pool.PopLastOrCreate();
            field.Initialise(declaringType, nameSource);
            field.FieldType = fieldType;
            field.Value = value;

            // If the type can't actually be const, change to readonly.
            if (!Reflection.CanBeConst(fieldType))
            {
                field.Modifiers &= ~AccessModifiers.Const;
                field.Modifiers |= AccessModifiers.Static | AccessModifiers.Readonly;
            }

            return field;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Get a <see cref="FieldBuilder"/> from the object pool and initialise it with the specified parameters.
        /// </summary>
        public static FieldBuilder Get<T>(TypeBuilder declaringType, string nameSource, T value)
        {
            return Get(declaringType, nameSource, typeof(T), value);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Constructs a new <see cref="FieldBuilder"/> with the default values.
        /// <para></para>
        /// Consider using one of the overloads of Get instead, in order to utilise object pooling to minimise memory
        /// allocation and garbage collection.
        /// </summary>
        public FieldBuilder()
            : base(AccessModifiers.Public | AccessModifiers.Const)
        {
            ValueEquals = DefaultValueEquals;
            AppendInitialiser = DefaultAppendInitialiser;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Reset this <see cref="FieldBuilder"/> and add it to its object pool to be reused later.
        /// </summary>
        public override void ReleaseToPool()
        {
            Reset();
            ExistingField = null;
            ValueEquals = DefaultValueEquals;
            AppendInitialiser = DefaultAppendInitialiser;
            UseGlobalFieldTypeName = false;
            Pool.Add(this);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        /// <summary>
        /// The default delegate assigned to <see cref="AppendInitialiser"/>.
        /// It simply calls <see cref="CSharp.GetInitialiser"/> and appends the result if it isn't null.
        /// </summary>
        public static readonly AppendInitialiserMethod
            DefaultAppendInitialiser = (text, indent, value) =>
            {
                var initialiser = CSharp.GetInitialiser(value);
                if (initialiser != null)
                    text.Append(" = ").Append(initialiser);
            };

        /************************************************************************************************************************/

        /// <summary>
        /// Checks if the <see cref="ElementBuilder.Name"/>, <see cref="MemberBuilder.Modifiers"/>,
        /// <see cref="FieldType"/>, and <see cref="Value"/> match the `existingMember`.
        /// <para></para>
        /// If the member matches, this method returns true and the member can be accessed via <see cref="ExistingMember"/>.
        /// </summary>
        public override bool IsExistingMember(MemberInfo existingMember, ref bool shouldRebuild)
        {
            if (!base.IsExistingMember(existingMember, ref shouldRebuild))
                return false;

            ExistingField = existingMember as FieldInfo;

            if (ExistingField == null || !CSharp.HasModifiers(ExistingField, Modifiers))
            {
                Parent.ScriptBuilder.LogRebuildReason(ExistingField.GetNameCS() + " is not a " + Modifiers.GetDeclaration() + " field.");
                shouldRebuild = true;
            }
            else if (ExistingField.FieldType != FieldType)
            {
                Parent.ScriptBuilder.LogRebuildReason(ExistingField.GetNameCS() + " is not a " + FieldType.GetNameCS() + " field.");
                shouldRebuild = true;
            }
            else if (ValueEquals != null && ExistingField.IsStatic)
            {
                var value = ExistingField.GetValue(null);
                if (!ValueEquals(value))
                {
                    Parent.ScriptBuilder.LogRebuildReason("the value of " + ExistingField.GetNameCS() + " is not correct: '" + value + "' should be '" + Value + "'");
                    shouldRebuild = true;
                }
            }

            return true;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Uses <see cref="object.Equals(object, object)"/> to determine if the <see cref="Value"/> is equal to <paramref name="other"/>.
        /// </summary>
        public bool DefaultValueEquals(object other)
        {
            return Equals(Value, other);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends the declaration of this field in C# code to the specified `text`.
        /// </summary>
        public override void AppendScript(StringBuilder text, int indent)
        {
            Utils.DebugLog(Utils.GetStringBuilder().Indent(indent).Append("Building ").Append(this).ReleaseToString());

            AppendHeader(text, indent);

            text.Indent(indent);
            Modifiers.AppendDeclaration(text);

            text.Append(FieldType.GetNameCS(UseGlobalFieldTypeName ? CSharp.NameVerbosity.GlobalFullName : CSharp.NameVerbosity.FullName))
                .Append(' ')
                .Append(Name);

            AppendInitialiser?.Invoke(text, indent, Value);

            text.AppendLineConst(";");
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns a summary of this field including its type, <see cref="ElementBuilder.NameSource"/>,
        /// <see cref="ElementBuilder.Name"/>, <see cref="ElementBuilder.FullName"/>, and <see cref="Value"/>.
        /// </summary>
        public override string ToString()
        {
            return base.ToString() + ", Value=" + Value;
        }

        /************************************************************************************************************************/
    }
}

#endif
