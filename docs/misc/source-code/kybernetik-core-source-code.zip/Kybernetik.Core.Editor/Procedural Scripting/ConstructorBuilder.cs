﻿// Kybernetik // Copyright 2019 Kybernetik //

#if PROCEDURAL_SCRIPTING

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Kybernetik.ProceduralScripting
{
    /// <summary>
    /// Manages the details for building a constructor in a procedural C# script.
    /// </summary>
    public class ConstructorBuilder : MemberBuilder
    {
        /************************************************************************************************************************/
        #region Fields and Properties
        /************************************************************************************************************************/

        /// <summary>
        /// The types of each of this method's parameters. Corresponds to the <see cref="ParameterInfo.ParameterType"/>
        /// of each parameter returned by <see cref="MethodBase.GetParameters"/>.
        /// </summary>
        public Type[] ParameterTypes { get; private set; }

        /// <summary>
        /// The types of each of this method's parameters. Corresponds to the <see cref="ParameterInfo.Name"/>
        /// of each parameter returned by <see cref="MethodBase.GetParameters"/>.
        /// </summary>
        public string[] ParameterNames { get; private set; }

        /// <summary>
        /// This delegate is used to build the body of this method.
        /// </summary>
        public AppendFunction BodyBuilder { get; private set; }

        /// <summary>
        /// If true, this method will be built on a single line, I.E. "{ ...Method Body... }".
        /// </summary>
        public bool IsSingleLine { get; set; }

        /************************************************************************************************************************/

        /// <summary>
        /// The <see cref="ConstructorInfo"/> of the method with the same parameters as this builder.
        /// This property is gathered by <see cref="IsExistingMember(MemberInfo, ref bool)"/>.
        /// </summary>
        public ConstructorInfo ExistingConstructor { get; private set; }

        /// <summary>
        /// The <see cref="ConstructorInfo"/> of the method with the same parameters as this builder.
        /// This property is gathered by <see cref="IsExistingMember(MemberInfo, ref bool)"/>.
        /// </summary>
        public override MemberInfo ExistingMember => ExistingConstructor;

        /************************************************************************************************************************/

        /// <summary>This is a <see cref="MemberTypes.Constructor"/>.</summary>
        public override MemberTypes MemberType => MemberTypes.Constructor;

        /************************************************************************************************************************/

        /// <summary>
        /// Returns the default method to use to build XML comments for this member. Called once by the constructor.
        /// </summary>
        protected override Action<StringBuilder> GetDefaultCommentBuilder()
        {
            return (comment) => comment.Append("Creates a new <see cref=\"").Append(Parent.Name).Append("\"/>");
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Constructs a new <see cref="ConstructorBuilder"/> with default values.
        /// <para></para>
        /// Consider using one of the overloads of Get instead, in order to utilise object pooling to minimise memory
        /// allocation and garbage collection.
        /// </summary>
        public ConstructorBuilder()
            : base(AccessModifiers.Public)
        { }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Pooling
        /************************************************************************************************************************/

        private static readonly List<ConstructorBuilder> Pool = new List<ConstructorBuilder>();

        /************************************************************************************************************************/

        /// <summary>
        /// Get a <see cref="ConstructorBuilder"/> from the object pool and initialise it with the specified parameters.
        /// </summary>
        public static ConstructorBuilder Get(TypeBuilder declaringType,
            Type[] parameterTypes, string[] parameterNames, AppendFunction bodyBuilder)
        {
            var constructor = Pool.PopLastOrCreate();
            constructor.Initialise(declaringType, GetName(parameterTypes));
            constructor.ParameterTypes = parameterTypes;
            constructor.ParameterNames = parameterNames;
            constructor.BodyBuilder = bodyBuilder;

            Utils.EditorAssert(parameterTypes.Length == parameterNames.Length, "parameterTypes.Length != parameterNames.Length");

            return constructor;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Get a <see cref="ConstructorBuilder"/> from the object pool and initialise it with the specified parameters.
        /// </summary>
        public static ConstructorBuilder Get(TypeBuilder declaringType, AppendFunction bodyBuilder)
        {
            var constructor = Pool.PopLastOrCreate();
            constructor.Initialise(declaringType, GetName(null));
            constructor.BodyBuilder = bodyBuilder;
            return constructor;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Reset this <see cref="MethodBuilder"/> and add it to its object pool to be reused later.
        /// </summary>
        public override void ReleaseToPool()
        {
            Reset();
            ExistingConstructor = null;
            IsSingleLine = false;
            Pool.Add(this);
        }

        /************************************************************************************************************************/

        private static string GetName(Type[] parameterTypes)
        {
            if (parameterTypes == null || parameterTypes.Length == 0)
                return "ctor";

            var name = Utils.GetStringBuilder();
            name.Append("ctor_");
            for (int i = 0; i < parameterTypes.Length; i++)
            {
                if (i > 0)
                    name.Append('_');

                name.Append(CSharp.ValidateMemberName(parameterTypes[i].GetNameCS(), true));
            }
            return name.ReleaseToString();
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        /// <summary>
        /// Checks if the <see cref="ElementBuilder.Name"/>, <see cref="MemberBuilder.Modifiers"/>, and parameters match
        /// the `existingMember`.
        /// <para></para>
        /// If the member matches, this method returns true and the member can be accessed via <see cref="ExistingMember"/>.
        /// </summary>
        public override bool IsExistingMember(MemberInfo existingMember, ref bool shouldRebuild)
        {
            if (ExistingMember != null)
                return false;

            ExistingConstructor = existingMember as ConstructorInfo;
            if (ExistingConstructor == null)
                return false;

            var parameters = ExistingConstructor.GetParameters();
            if (parameters.Length == 0)
            {
                if (ParameterTypes != null && ParameterTypes.Length != 0)
                {
                    ExistingConstructor = null;
                    return false;
                }
            }
            else
            {
                for (int i = 0; i < parameters.Length; i++)
                {
                    var parameter = parameters[i];
                    if (parameter.ParameterType != ParameterTypes[i] ||
                        parameter.Name != ParameterNames[i])
                    {
                        ExistingConstructor = null;
                        return false;
                    }
                }
            }

            if (!CSharp.HasModifiers(ExistingConstructor, Modifiers))
            {
                Parent.ScriptBuilder.LogRebuildReason(existingMember.GetNameCS() + " is not a " + Modifiers.GetDeclaration() + " constructor.");
                shouldRebuild = true;
            }

            return true;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends the declaration of this method in C# code to the specified `text`.
        /// </summary>
        public override void AppendScript(StringBuilder text, int indent)
        {
            Utils.DebugLog(Utils.GetStringBuilder().Indent(indent).Append("Building ").Append(this).ReleaseToString());

            AppendHeader(text, indent);

            text.Indent(indent);
            Modifiers.AppendDeclaration(text);
            text.Append(Parent.Name)
                .Append('(');

            if (ParameterTypes != null)
            {
                for (int i = 0; i < ParameterTypes.Length; i++)
                {
                    if (i > 0)
                        text.Append(", ");

                    text.Append(ParameterTypes[i].GetNameCS())
                        .Append(' ')
                        .Append(ParameterNames[i]);
                }
            }

            text.Append(')');

            if (IsSingleLine)
            {
                text.Append(" { ");
                BodyBuilder(text, indent);
                text.AppendLineConst(" }");
            }
            else
            {
                text.AppendLineConst();
                text.OpenScope(ref indent);
                BodyBuilder(text, indent);
                text.CloseScope(ref indent);
            }
        }

        /************************************************************************************************************************/
    }
}

#endif
