﻿// Kybernetik // Copyright 2019 Kybernetik //

#if PROCEDURAL_SCRIPTING

using System;
using System.Text;

namespace Kybernetik.ProceduralScripting
{
    /// <summary>
    /// A delegate which appends some text at the specified `indent` level.
    /// </summary>
    public delegate void AppendFunction(StringBuilder text, int indent);
}

#endif
