﻿// Kybernetik // Copyright 2019 Kybernetik //

#if PROCEDURAL_SCRIPTING

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using UnityEngine;

namespace Kybernetik.ProceduralScripting
{
    /// <summary>
    /// Manages the details for building a method in a procedural C# script.
    /// </summary>
    public class MethodBuilder : MemberBuilder
    {
        /************************************************************************************************************************/
        #region Fields and Properties
        /************************************************************************************************************************/

        /// <summary>
        /// The type of object this method returns. Corresponds to <see cref="MethodInfo.ReturnType"/>.
        /// </summary>
        public Type ReturnType { get; private set; }

        /// <summary>
        /// The types of each of this method's parameters. Corresponds to the <see cref="ParameterInfo.ParameterType"/>
        /// of each parameter returned by <see cref="MethodBase.GetParameters"/>.
        /// </summary>
        public Type[] ParameterTypes { get; private set; }

        /// <summary>
        /// The types of each of this method's parameters. Corresponds to the <see cref="ParameterInfo.Name"/>
        /// of each parameter returned by <see cref="MethodBase.GetParameters"/>.
        /// </summary>
        public string[] ParameterNames { get; private set; }

        /// <summary>
        /// If set to true, the first parameter will be given the "this" modifier, making this an extension method.
        /// </summary>
        public bool IsExtensionMethod { get; set; }

        /// <summary>
        /// This delegate is used to build the body of this method.
        /// </summary>
        public AppendFunction BodyBuilder { get; private set; }

        /// <summary>
        /// If true, this method will be built on a single line, I.E. "{ ...Method Body... }".
        /// </summary>
        public bool IsSingleLine { get; set; }

        /************************************************************************************************************************/

        /// <summary>
        /// The <see cref="MethodInfo"/> of the method with the same type and name as this builder.
        /// This property is gathered by <see cref="IsExistingMember(MemberInfo, ref bool)"/>.
        /// </summary>
        public MethodInfo ExistingMethod { get; private set; }

        /// <summary>
        /// The <see cref="MethodInfo"/> of the method with the same type and name as this builder.
        /// This property is gathered by <see cref="IsExistingMember(MemberInfo, ref bool)"/>.
        /// </summary>
        public override MemberInfo ExistingMember => ExistingMethod;

        /************************************************************************************************************************/

        /// <summary>This is a <see cref="MemberTypes.Method"/>.</summary>
        public override MemberTypes MemberType => MemberTypes.Method;

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Pooling
        /************************************************************************************************************************/

        private static readonly List<MethodBuilder> Pool = new List<MethodBuilder>();

        /************************************************************************************************************************/

        /// <summary>
        /// Get a <see cref="MethodBuilder"/> from the object pool and initialise it with the specified parameters.
        /// </summary>
        public static MethodBuilder Get(TypeBuilder declaringType, string nameSource, Type returnType,
            Type[] parameterTypes, string[] parameterNames, AppendFunction bodyBuilder)
        {
            var method = Pool.PopLastOrCreate();
            method.Initialise(declaringType, nameSource);
            method.ReturnType = returnType;
            method.ParameterTypes = parameterTypes;
            method.ParameterNames = parameterNames;
            method.BodyBuilder = bodyBuilder;

            Utils.EditorAssert(parameterTypes.Length == parameterNames.Length, "parameterTypes.Length != parameterNames.Length");

            return method;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Get a <see cref="MethodBuilder"/> from the object pool and initialise it with the specified parameters.
        /// </summary>
        public static MethodBuilder Get(TypeBuilder declaringType, string nameSource, Type returnType, AppendFunction bodyBuilder)
        {
            var method = Pool.PopLastOrCreate();
            method.Initialise(declaringType, nameSource);
            method.ReturnType = returnType;
            method.BodyBuilder = bodyBuilder;
            return method;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Get a <see cref="MethodBuilder"/> from the object pool and initialise it with the specified parameters.
        /// </summary>
        public static MethodBuilder Get(TypeBuilder declaringType, string nameSource, AppendFunction bodyBuilder)
        {
            return Get(declaringType, nameSource, typeof(void), bodyBuilder);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Reset this <see cref="MethodBuilder"/> and add it to its object pool to be reused later.
        /// </summary>
        public override void ReleaseToPool()
        {
            Reset();
            ExistingMethod = null;
            IsExtensionMethod = false;
            IsSingleLine = false;
            Pool.Add(this);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        /// <summary>
        /// Checks if the <see cref="ElementBuilder.Name"/>, <see cref="MemberBuilder.Modifiers"/>,
        /// <see cref="ReturnType"/>, and parameters match the `existingMember`.
        /// <para></para>
        /// If the member matches, this method returns true and the member can be accessed via <see cref="ExistingMember"/>.
        /// </summary>
        public override bool IsExistingMember(MemberInfo existingMember, ref bool shouldRebuild)
        {
            if (!base.IsExistingMember(existingMember, ref shouldRebuild))
                return false;

            ExistingMethod = existingMember as MethodInfo;

            if (ExistingMethod == null || !CSharp.HasModifiers(ExistingMethod, Modifiers))
            {
                Parent.ScriptBuilder.LogRebuildReason(existingMember.GetNameCS() + " is not a " + Modifiers.GetDeclaration() + " method.");
                shouldRebuild = true;
            }
            else if (ExistingMethod.ReturnType != ReturnType)
            {
                Parent.ScriptBuilder.LogRebuildReason(existingMember.GetNameCS() + " is doesn't return " + ReturnType.GetNameCS() + ".");
                shouldRebuild = true;
            }
            else
            {
                var parameters = ExistingMethod.GetParameters();
                if (parameters.Length == 0)
                {
                    if (ParameterTypes != null)
                    {
                        Parent.ScriptBuilder.LogRebuildReason(existingMember.GetNameCS() + " parameters have changed.");
                        shouldRebuild = true;
                    }
                }
                else
                {
                    if (IsExtensionMethod != ExistingMethod.IsDefined(typeof(ExtensionAttribute), true))
                    {
                        Parent.ScriptBuilder.LogRebuildReason(existingMember.GetNameCS() + (IsExtensionMethod ? " should be an extension method." : " shouldn't be an extension method."));
                        shouldRebuild = true;
                    }

                    for (int i = 0; i < parameters.Length; i++)
                    {
                        var parameter = parameters[i];
                        if (parameter.ParameterType != ParameterTypes[i] ||
                            parameter.Name != ParameterNames[i])
                        {
                            Parent.ScriptBuilder.LogRebuildReason(existingMember.GetNameCS() + " parameters have changed.");
                            shouldRebuild = true;
                        }
                    }
                }
            }

            return true;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends the declaration of this method in C# code to the specified `text`.
        /// </summary>
        public override void AppendScript(StringBuilder text, int indent)
        {
            Utils.DebugLog(Utils.GetStringBuilder().Indent(indent).Append("Building ").Append(this).ReleaseToString());

            AppendHeader(text, indent);

            text.Indent(indent);
            Modifiers.AppendDeclaration(text);
            text.Append(ReturnType.GetNameCS())
                .Append(' ')
                .Append(Name)
                .Append('(');

            if (ParameterTypes != null)
            {
                for (int i = 0; i < ParameterTypes.Length; i++)
                {
                    if (i == 0)
                    {
                        if (IsExtensionMethod)
                            text.Append("this ");
                    }
                    else
                    {
                        text.Append(", ");
                    }

                    text.Append(ParameterTypes[i].GetNameCS())
                        .Append(' ')
                        .Append(ParameterNames[i]);
                }
            }

            text.Append(')');

            if (IsSingleLine)
            {
                text.Append(" { ");
                BodyBuilder(text, indent);
                text.AppendLineConst(" }");
            }
            else
            {
                text.AppendLineConst();
                text.OpenScope(ref indent);
                BodyBuilder(text, indent);
                text.CloseScope(ref indent);
            }
        }

        /************************************************************************************************************************/
    }
}

#endif
