﻿// Kybernetik // Copyright 2019 Kybernetik //

//#define UNIT_TEST

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;

namespace Kybernetik
{
    /// <summary>
    /// A variety of methods relating to C# code.
    /// Particularly useful for generating procedural code.
    /// </summary>
    public static partial class CSharp
    {
        /************************************************************************************************************************/

        static CSharp()
        {
            Utils.LogCallerIfRestricted();
        }

        /************************************************************************************************************************/
        #region Type Keywords
        /************************************************************************************************************************/

        private static Dictionary<Type, string> _TypeKeywords;

        private static void InitialiseTypeKeywords()
        {
            if (_TypeKeywords != null)
                return;

            _TypeKeywords = new Dictionary<Type, string>
            {
                { typeof(void), "void" },
                { typeof(object), "object" },
                { typeof(bool), "bool" },
                { typeof(byte), "byte" },
                { typeof(sbyte), "sbyte" },
                { typeof(char), "char" },
                { typeof(string), "string" },
                { typeof(short), "short" },
                { typeof(int), "int" },
                { typeof(long), "long" },
                { typeof(ushort), "ushort" },
                { typeof(uint), "uint" },
                { typeof(ulong), "ulong" },
                { typeof(float), "float" },
                { typeof(double), "double" },
                { typeof(decimal), "decimal" },
            };
        }

        /************************************************************************************************************************/

        /// <summary>Returns true if the specified `type` is associated with a C# keyword such as <see cref="int"/>, <see cref="float"/>, <see cref="string"/>, etc.</summary>
        public static bool HasKeyword(Type type)
        {
            InitialiseTypeKeywords();
            return _TypeKeywords.ContainsKey(type);
        }

        /// <summary>
        /// Returns the C# keyword associated with the specified `type` such as <see cref="int"/>, <see cref="float"/>, <see cref="string"/>, etc.
        /// Returns null if there is no associated keyword.
        /// </summary>
        public static string GetKeyword(Type type)
        {
            InitialiseTypeKeywords();
            _TypeKeywords.TryGetValue(type, out var keyword);
            return keyword;
        }

        /************************************************************************************************************************/

        private static HashSet<string> _ReservedKeywords;

        /// <summary>
        /// Returns true if the `word` is reserved by the C# language.
        /// </summary>
        public static bool IsReservedKeyword(string word)
        {
            if (_ReservedKeywords == null)
            {
                _ReservedKeywords = new HashSet<string>
                {
                    "abstract",
                    "as",
                    "base",
                    "bool",
                    "break",
                    "byte",
                    "case",
                    "catch",
                    "char",
                    "checked",
                    "class",
                    "const",
                    "continue",
                    "decimal",
                    "default",
                    "delegate",
                    "do",
                    "double",
                    "else",
                    "enum",
                    "event",
                    "explicit",
                    "extern",
                    "false",
                    "finally",
                    "fixed",
                    "float",
                    "for",
                    "foreach",
                    "goto",
                    "if",
                    "implicit",
                    "in",
                    "int",
                    "interface",
                    "internal",
                    "is",
                    "lock",
                    "long",
                    "namespace",
                    "new",
                    "null",
                    "object",
                    "operator",
                    "out",
                    "override",
                    "params",
                    "private",
                    "protected",
                    "public",
                    "readonly",
                    "ref",
                    "return",
                    "sbyte",
                    "sealed",
                    "short",
                    "sizeof",
                    "stackalloc",
                    "static",
                    "string",
                    "struct",
                    "switch",
                    "this",
                    "throw",
                    "true",
                    "try",
                    "typeof",
                    "uint",
                    "ulong",
                    "unchecked",
                    "unsafe",
                    "ushort",
                    "using",
                    "static",
                    "void",
                    "volatile",
                    "while"
                };
            }

            return _ReservedKeywords.Contains(word);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Type Names
        /************************************************************************************************************************/

        /// <summary>Specifies how detailed the name returned by GetNameCS should be.</summary>
        public enum NameVerbosity
        {
            /// <summary>Similar to <see cref="Type.FullName"/>.</summary>
            FullName,

            /// <summary>Similar to <see cref="MemberInfo.Name"/>.</summary>
            Name,

            /// <summary>Similar to <see cref="Type.FullName"/>, with the "global::" prefix.</summary>
            GlobalFullName,
        }

        private const int NameVerbosityCount = 3;

        /************************************************************************************************************************/

        private static Dictionary<Type, string>[] _TypeToName;

        private static Dictionary<Type, string> GetTypeToName(NameVerbosity nameVerbosity)
        {
            if (_TypeToName == null)
                _TypeToName = new Dictionary<Type, string>[NameVerbosityCount];

            var index = (int)nameVerbosity;
            var names = _TypeToName[index];
            if (names == null)
            {
                InitialiseTypeKeywords();
                names = new Dictionary<Type, string>(_TypeKeywords);
                _TypeToName[index] = names;
            }
            return names;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns the name of a `type` as it would appear in C# code.
        /// <para></para>
        /// For example, typeof(List&lt;float&gt;).FullName would give you:
        /// System.Collections.Generic.List`1[[System.Single, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]
        /// <para></para>
        /// This method would instead return a different result depending on the specified `nameVerbosity`:
        /// <para></para><see cref="NameVerbosity.Name"/> would return "List&lt;float&gt;"
        /// <para></para><see cref="NameVerbosity.FullName"/> would return "System.Collections.Generic.List&lt;float&gt;"
        /// <para></para><see cref="NameVerbosity.GlobalFullName"/> would return "global::System.Collections.Generic.List&lt;float&gt;"
        /// <para></para>
        /// Note that all returned values are cached to speed up repeated use.
        /// </summary>
        public static string GetNameCS(this Type type, NameVerbosity nameVerbosity = NameVerbosity.FullName)
        {
            if (type == null)
                return "";

            // Check if we have already got the name for that type.
            var names = GetTypeToName(nameVerbosity);
            if (names.TryGetValue(type, out string name))
                return name;

            var text = Utils.GetStringBuilder();

            if (type.IsArray)// Array = TypeName[].
            {
                text.Append(type.GetElementType().GetNameCS(nameVerbosity));

                text.Append('[');
                var dimensions = type.GetArrayRank();
                while (dimensions-- > 1)
                    text.Append(',');
                text.Append(']');

                goto Return;
            }

            if (type.IsPointer)// Pointer = TypeName*.
            {
                text.Append(type.GetElementType().GetNameCS(nameVerbosity));
                text.Append('*');

                goto Return;
            }

            if (type.IsGenericParameter)// Generic Parameter = TypeName (for unspecified generic parameters).
            {
                text.Append(type.Name);
                goto Return;
            }

            var underlyingType = Nullable.GetUnderlyingType(type);
            if (underlyingType != null)// Nullable = TypeName?.
            {
                text.Append(underlyingType.GetNameCS(nameVerbosity));
                text.Append('?');

                goto Return;
            }

            // Other Type = Namespace.NestedTypes.TypeName<GenericArguments>.

            if (nameVerbosity == NameVerbosity.GlobalFullName && !HasKeyword(type))// Global prefix.
            {
                text.Append("global::");
            }

            var fullName = nameVerbosity != NameVerbosity.Name;
            if (fullName && type.Namespace != null)// Namespace.
            {
                text.Append(type.Namespace);
                text.Append('.');
            }

            var skipGenericArguments = 0;

            if (fullName && type.DeclaringType != null)// Account for Nested Types.
            {
                // Count the nesting level.
                var nesting = 1;
                var declaringType = type.DeclaringType;
                while (declaringType.DeclaringType != null)
                {
                    declaringType = declaringType.DeclaringType;
                    nesting++;
                }

                // Append the name of each outer type, starting from the outside.
                // For each nesting level starting from the outside, walk out to it from the specified 'type'.
                // This avoids the need to make a list of types in the nest or to insert type names instead of appending them.
                while (nesting-- > 0)
                {
                    declaringType = type;
                    for (int i = nesting; i >= 0; i--)
                        declaringType = declaringType.DeclaringType;

                    // Nested Type Name and Generic Arguments.
                    skipGenericArguments = AppendNameAndGenericArguments(text, declaringType, nameVerbosity, skipGenericArguments);
                    text.Append('.');
                }
            }

            // Type Name and Generic Arguments.
            skipGenericArguments = AppendNameAndGenericArguments(text, type, nameVerbosity, skipGenericArguments);

            Return:// Cache and return the name.

            name = text.ReleaseToString();
            names.Add(type, name);
            return name;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends the name and generic arguments of `type` (after skipping the specified number).
        /// Returns the index of the last argument.
        /// </summary>
        public static int AppendNameAndGenericArguments(StringBuilder text, Type type, NameVerbosity nameVerbosity = NameVerbosity.FullName, int skipGenericArguments = 0)
        {
            text.Append(type.Name);

            if (type.IsGenericType)
            {
                var backQuote = type.Name.IndexOf('`');
                if (backQuote >= 0)
                {
                    text.Length -= type.Name.Length - backQuote;

                    var genericArguments = type.GetGenericArguments();
                    if (skipGenericArguments < genericArguments.Length)
                    {
                        text.Append('<');

                        var firstArgument = genericArguments[skipGenericArguments];
                        skipGenericArguments++;

                        if (firstArgument.IsGenericParameter)
                        {
                            while (skipGenericArguments < genericArguments.Length)
                            {
                                text.Append(',');
                                skipGenericArguments++;
                            }
                        }
                        else
                        {
                            text.Append(firstArgument.GetNameCS(nameVerbosity));

                            while (skipGenericArguments < genericArguments.Length)
                            {
                                text.Append(", ");
                                text.Append(genericArguments[skipGenericArguments].GetNameCS(nameVerbosity));
                                skipGenericArguments++;
                            }
                        }

                        text.Append('>');
                    }
                }
            }

            return skipGenericArguments;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Member Names
        /************************************************************************************************************************/

        /// <summary>
        /// Returns the full name of a `member` as it would appear in C# code.
        /// <para></para>
        /// For example, passing the <see cref="MethodInfo"/> of this method in as its own parameter would return "<see cref="CSharp"/>.GetNameCS".
        /// <para></para>
        /// Note that when `member` is a <see cref="Type"/>, this method calls <see cref="GetNameCS(Type, NameVerbosity)"/> instead.
        /// </summary>
        public static string GetNameCS(this MemberInfo member, NameVerbosity declaringTypeNameVerbosity = NameVerbosity.FullName)
        {
            if (member == null)
                return "null";

            if (member is Type type)
                return type.GetNameCS(declaringTypeNameVerbosity);

            // Check if we have already got the name for that member.
            var names = GetMemberToName(declaringTypeNameVerbosity);
            if (names.TryGetValue(member, out string name))
                return name;

            // Otherwise build a new one.
            var text = Utils.GetStringBuilder();

            if (member.DeclaringType != null)
            {
                text.Append(member.DeclaringType.GetNameCS(declaringTypeNameVerbosity));
                text.Append('.');
            }

            text.Append(member.Name);

            name = text.ReleaseToString();
            names.Add(member, name);
            return name;
        }

        /************************************************************************************************************************/

        private static Dictionary<MemberInfo, string>[] _MemberToName;

        private static Dictionary<MemberInfo, string> GetMemberToName(NameVerbosity declaringTypeNameVerbosity)
        {
            if (_MemberToName == null)
                _MemberToName = new Dictionary<MemberInfo, string>[NameVerbosityCount];

            var index = (int)declaringTypeNameVerbosity;
            var names = _MemberToName[index];
            if (names == null)
            {
                names = new Dictionary<MemberInfo, string>();
                _MemberToName[index] = names;
            }
            return names;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Compares the declaring type namespaces, then declaring type names, then member names.
        /// </summary>
        public static int CompareNamespaceTypeMember(MemberInfo a, MemberInfo b)
        {
            var result = string.Compare(a.DeclaringType.Namespace, b.DeclaringType.Namespace);
            if (result != 0)
                return result;

            result = string.Compare(a.DeclaringType.FullName, b.DeclaringType.FullName);
            if (result != 0)
                return result;

            return string.Compare(a.Name, b.Name);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Friendly Method Names
        /************************************************************************************************************************/

        /// <summary>Returns the full name of a  `method` as it would appear in C# code. See: <see cref="GetNameCS(MemberInfo, NameVerbosity)"/>.</summary>
        public static string GetNameCS(Delegate method)
        {
            return GetNameCS(method.Method);
        }

        /// <summary>Returns the full name of a  `method` as it would appear in C# code. See: <see cref="GetNameCS(MemberInfo, NameVerbosity)"/>.</summary>
        public static string GetNameCS(Action method)
        {
            return GetNameCS(method.Method);
        }

        /// <summary>Returns the full name of a  `method` as it would appear in C# code. See: <see cref="GetNameCS(MemberInfo, NameVerbosity)"/>.</summary>
        public static string GetNameCS<T>(Action<T> method)
        {
            return GetNameCS(method.Method);
        }

        /// <summary>Returns the full name of a  `method` as it would appear in C# code. See: <see cref="GetNameCS(MemberInfo, NameVerbosity)"/>.</summary>
        public static string GetNameCS<TResult>(Func<TResult> method)
        {
            return GetNameCS(method.Method);
        }

        /// <summary>Returns the full name of a  `method` as it would appear in C# code. See: <see cref="GetNameCS(MemberInfo, NameVerbosity)"/>.</summary>
        public static string GetNameCS<T, TResult>(Func<T, TResult> method)
        {
            return GetNameCS(method.Method);
        }

        /// <summary>Returns the full name of a  `method` as it would appear in C# code. See: <see cref="GetNameCS(MemberInfo, NameVerbosity)"/>.</summary>
        public static string GetNameCS<T1, T2, TResult>(Func<T1, T2, TResult> method)
        {
            return GetNameCS(method.Method);
        }

        /************************************************************************************************************************/

        /// <summary>Appends the signature of `method` as it would appear in C# code.</summary>
        public static void AppendSignature(MethodInfo method, StringBuilder text, NameVerbosity nameVerbosity = NameVerbosity.FullName,
            bool returnType = true, bool declaringType = true, bool parameterTypes = true, bool parameterDetails = true)
        {
            if (method == null)
            {
                text.Append("null");
                return;
            }

            if (returnType)
            {
                text.Append(method.ReturnType.GetNameCS(nameVerbosity));
                text.Append(' ');
            }

            if (declaringType)
            {
                text.Append(method.DeclaringType.GetNameCS(nameVerbosity));
                text.Append('.');
            }

            text.Append(method.Name);

            if (method.IsGenericMethod)
            {
                text.Append('<');

                var genericArguments = method.GetGenericArguments();
                for (int i = 0; i < genericArguments.Length; i++)
                {
                    text.Append(genericArguments[i].GetNameCS(nameVerbosity));
                    text.Append(", ");
                }

                text.Length -= 2;
                text.Append('>');
            }

            text.Append('(');
            {
                if (parameterTypes)
                {
                    if (method.IsDefined(typeof(ExtensionAttribute), false))
                        text.Append("this ");

                    AppendParameters(text, method.GetParameters(), parameterDetails);
                }
            }
            text.Append(')');
        }

        /// <summary>Returns the signature of `method` as it would appear in C# code.</summary>
        public static string GetSignature(this MethodInfo method, NameVerbosity nameVerbosity = NameVerbosity.FullName,
            bool returnType = true, bool declaringType = true, bool parameters = true, bool parameterDetails = true)
        {
            if (method == null)
                return "null";

            var text = Utils.GetStringBuilder();
            AppendSignature(method, text, nameVerbosity, returnType, declaringType, parameters, parameterDetails);
            return text.ReleaseToString();
        }

        /************************************************************************************************************************/

        /// <summary>Appends the signature of a method with the specified details as it would appear in C# code.</summary>
        public static void AppendMethodSignature(StringBuilder text,
            Type returnType, Type declaringType, string methodName, Type[] genericArguments, Type[] parameterTypes, NameVerbosity nameVerbosity = NameVerbosity.FullName)
        {
            if (returnType != null)
            {
                text.Append(returnType.Name);
                text.Append(' ');
            }

            if (declaringType != null)
            {
                text.Append(declaringType.GetNameCS(nameVerbosity));
                text.Append('.');
            }

            text.Append(methodName);

            if (genericArguments != null)
            {
                text.Append('<');

                for (int i = 0; i < genericArguments.Length; i++)
                {
                    if (i > 0)
                        text.Append(", ");

                    text.Append(genericArguments[i].GetNameCS(nameVerbosity));
                }

                text.Append('>');
            }

            text.Append('(');
            if (parameterTypes != null)
            {
                for (int i = 0; i < parameterTypes.Length; i++)
                {
                    if (i > 0)
                        text.Append(", ");

                    text.Append(parameterTypes[i].GetNameCS(nameVerbosity));
                }
            }
            text.Append(')');
        }

        /************************************************************************************************************************/

        /// <summary>Appends the signature of `method` as it would appear in C# code.</summary>
        public static void AppendParameters(StringBuilder text, ParameterInfo[] parameters, bool parameterDetails = true, NameVerbosity nameVerbosity = NameVerbosity.FullName)
        {
            for (int i = 0; i < parameters.Length; i++)
            {
                if (i > 0)
                    text.Append(", ");

                var parameter = parameters[i];

                if (parameter.IsOut)
                    text.Append("out ");
                else if (parameter.ParameterType.IsByRef)
                    text.Append("ref ");

                text.Append(parameter.ParameterType.GetNameCS(nameVerbosity));

                if (parameterDetails)
                {
                    text.Append(' ');
                    text.Append(parameter.Name);

                    if (parameter.IsOptional)
                    {
#if PROCEDURAL_SCRIPTING
                        var initialiser = GetInitialiser(parameter.DefaultValue);
                        if (initialiser != null)
                        {
                            text.Append('=');
                            text.Append(initialiser);
                        }
#else
                        text.Append('=');
                        text.Append(parameter.DefaultValue);
#endif
                    }
                }
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Unit Tests
#if UNIT_TEST
        /************************************************************************************************************************/

        [UnitTest]
        private static void UnitTestGetNameCS()
        {
            // Primitives.
            UnitTestGetNameCS(typeof(bool), "bool");
            UnitTestGetNameCS(typeof(int), "int");

            // Arrays.
            UnitTestGetNameCS(typeof(bool[]), "bool[]");
            UnitTestGetNameCS(typeof(bool[][]), "bool[][]");
            UnitTestGetNameCS(typeof(bool[,,]), "bool[,,]");

            // Pointers and Nullables.
            UnitTestGetNameCS(typeof(bool*), "bool*");
            UnitTestGetNameCS(typeof(bool?), "bool?");

            // Generics.
            UnitTestGetNameCS(typeof(List<bool>),
                "List<bool>",
                "System.Collections.Generic.List<bool>");
            UnitTestGetNameCS(typeof(List<List<bool>[]>[]),
                "List<List<bool>[]>[]",
                "System.Collections.Generic.List<System.Collections.Generic.List<bool>[]>[]");

            // Nested Types.
            UnitTestGetNameCS(typeof(Nested), "Utils.Nested", "InspectorGadgets.Utils.Nested");
            UnitTestGetNameCS(typeof(Nested.Generic<float>.AnotherNested.AnotherGeneric<int>),
                "Utils.Nested.Generic<float>.AnotherNested.AnotherGeneric<int>",
                "InspectorGadgets.Utils.Nested.Generic<float>.AnotherNested.AnotherGeneric<int>");
            UnitTestGetNameCS(typeof(List<Nested.Generic<float>>),
                "List<Utils.Nested.Generic<float>>",
                "System.Collections.Generic.List<InspectorGadgets.Utils.Nested.Generic<float>>");

            UnitTestGetNameCS(typeof(Nested.Generic<>.AnotherNested.AnotherGeneric<>),
                "Utils.Nested.Generic<>.AnotherNested.AnotherGeneric<>",
                "InspectorGadgets.Utils.Nested.Generic<>.AnotherNested.AnotherGeneric<>");// Unspecified generic parameters.
        }

        public static void UnitTestGetNameCS(Type type, string expectedName, string expectedFullName)
        {
            string name = type.GetNameCS(false);
            if (expectedName != name)
                throw new Exception("Expected:      " + expectedName + "\nGot:      " + name);

            name = type.GetNameCS(true);
            if (expectedFullName != name)
                throw new Exception("Expected:      " + expectedFullName + "\nGot:      " + name);
        }

        public static void UnitTestGetNameCS(Type type, string expected)
        {
            UnitTestGetNameCS(type, expected, expected);
        }

        internal class Nested
        {
            internal class Generic<T>
            {
                internal class AnotherNested
                {
                    internal class AnotherGeneric<U>
                    {
                    }
                }
            }
        }

        /************************************************************************************************************************/
#endif
        #endregion
        /************************************************************************************************************************/
    }
}
