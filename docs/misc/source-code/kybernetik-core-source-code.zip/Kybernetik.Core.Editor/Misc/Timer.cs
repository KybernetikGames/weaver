﻿// Kybernetik // Copyright 2019 Kybernetik //

using System;
using UnityEngine;
#if UNITY_EDITOR
using Float = System.Double;
#else
using Float = System.Single;
#endif

namespace Kybernetik
{
    /// <summary>A simple timer system that works both in the editor and at runtime using unscaled time.</summary>
    public sealed class Timer : IDisposable
    {
        /************************************************************************************************************************/

        private static readonly ObjectPool<Timer> SpareTimers = ObjectPool.CreateDefaultPool<Timer>();

        private Float _StartTime;

        private string _Prefix, _Suffix;

        /************************************************************************************************************************/

        /// <summary>Start a timer which will log the elapsed time when disposed.</summary>
        public static Timer Start(string prefix = null, string suffix = null)
        {
            var timer = SpareTimers.Acquire();
            timer._Prefix = prefix;
            timer._Suffix = suffix;
            timer.Restart();
            return timer;
        }

        /************************************************************************************************************************/

        /// <summary>Sets the current time as this timer's start time.</summary>
        public void Restart()
        {
#if UNITY_EDITOR
            _StartTime = UnityEditor.EditorApplication.timeSinceStartup;
#else
            _StartTime = Time.unscaledTime;
#endif
        }

        /************************************************************************************************************************/

        /// <summary>Returns the amount of time that has passed since this timer was started.</summary>
        public static Float CurrentTime =>
#if UNITY_EDITOR
            UnityEditor.EditorApplication.timeSinceStartup;
#else
            Time.unscaledTime;
#endif

        /************************************************************************************************************************/

        /// <summary>Returns the amount of time that has passed since this timer was started.</summary>
        public Float GetTime()
        {
            return CurrentTime - _StartTime;
        }

        /************************************************************************************************************************/

        /// <summary>Logs the amount of time that has passed since this timer was started.</summary>
        public void LogTime()
        {
            var time = GetTime();
            Debug.Log(_Prefix + time + _Suffix);
        }

        /************************************************************************************************************************/

        /// <summary>Returns this timer to the pool to be reused.</summary>
        public void Release()
        {
            SpareTimers.Release(this);
        }

        /************************************************************************************************************************/

        /// <summary>Logs the elapsed time and releases this timer.</summary>
        public void Dispose()
        {
            LogTime();
            Release();
        }

        /************************************************************************************************************************/
    }
}