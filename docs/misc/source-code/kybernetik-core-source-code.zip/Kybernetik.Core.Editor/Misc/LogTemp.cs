﻿// Kybernetik // Copyright 2019 Kybernetik //

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Object = UnityEngine.Object;

#if GLOBAL_EXTENSIONS
/// <summary>A variety of extension methods exposed to the global namespace.</summary>
public static partial class GlobalKybernetikExtensions
#else
namespace Kybernetik
{
    public static partial class Utils
#endif
{
    /************************************************************************************************************************/

    /// <summary>
    /// <code>Debug.Log(message, context)</code> with an [<see cref="ObsoleteAttribute"/>] warning so you remember
    /// to remove any calls.
    /// </summary>
    [Obsolete]
    public static T LogTemp<T>(
#if OBJECT_EXTENSIONS
        this
#endif
        T message, Object context = null)
    {
        if (context == null)
            context = message as Object;

        Debug.Log(message, context);
        return message;
    }

    /// <summary>
    /// <code>Debug.Log(prefix + ": " + message)</code> with an [<see cref="ObsoleteAttribute"/>] warning so you
    /// remember to remove any calls.
    /// </summary>
    [Obsolete]
    public static T LogTemp<T>(
#if OBJECT_EXTENSIONS
        this
#endif
        T message, object prefix, Object context = null)
    {
        if (context == null)
            context = message as Object;

        Debug.Log(prefix + ": " + message, context);
        return message;
    }

    /************************************************************************************************************************/

#if GLOBAL_EXTENSIONS
    /// <summary>Returns a string containing the value of each element in `collection` (each on a new line).</summary>
    public static string DeepToString(this IEnumerable collection)
    {
        return Kybernetik.Utils.DeepToString(collection, Kybernetik.Utils.NewLine);
    }
#endif

    /************************************************************************************************************************/
}
#if !GLOBAL_EXTENSIONS
}
#endif
