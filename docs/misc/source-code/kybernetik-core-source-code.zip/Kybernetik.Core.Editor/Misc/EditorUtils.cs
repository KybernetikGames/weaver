﻿// Kybernetik // Copyright 2019 Kybernetik //

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using Object = UnityEngine.Object;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Kybernetik
{
    public static partial class Utils
    {
        /************************************************************************************************************************/

        /// <summary>[Editor-Conditional] <code>target.name = name</code></summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorSetName(this Object target, string name)
        {
            target.name = name;
        }

        /************************************************************************************************************************/

#if UNITY_EDITOR
        private static Dictionary<string, Transform> _NameToParent;
#endif

        /// <summary>[Editor-Conditional]
        /// Sets the <see cref="Transform.parent"/> to a default object based on its name.
        /// <para></para>
        /// This keeps the hierarchy neat in the Unity Editor without wasting processing time on it at runtime.
        /// </summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorSetDefaultParent(Transform transform, string suffix = null)
        {
#if UNITY_EDITOR

            // Remove "(Clone)" from the end of the name to determine the parent name.
            var name = transform.name;
            while (name.EndsWith("(Clone)"))
                name = name.Substring(0, name.Length - 7);

            name += suffix;

            if (_NameToParent == null)
                _NameToParent = new Dictionary<string, Transform>();

            // Get or create a parent with that name.
            if (!_NameToParent.TryGetValue(name, out var parent))
            {
                parent = new GameObject(name).transform;
                Object.DontDestroyOnLoad(parent.gameObject);
                _NameToParent.Add(name, parent);
            }

            transform.SetParent(parent);

#endif
        }

        /************************************************************************************************************************/
#if UNITY_EDITOR
        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// If there are multiple components which inherit from <typeparamref name="T"/>, the first one is changed to
        /// the type of the second and any after the first are destroyed. This allows you to change the type without
        /// losing the values of any serialized fields they share.
        /// <para></para>
        /// The `currentComponent` is used to determine which <see cref="GameObject"/> to examine and the base
        /// component type <typeparamref name="T"/>.
        /// </summary>
        public static void IfMultiComponentThenChangeType<T>(T currentComponent) where T : MonoBehaviour
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                return;

            // If there is already another instance of this component on the same object, delete this new instance and
            // change the original's type to match this one.
            var components = currentComponent.GetComponents<T>();
            if (components.Length > 1)
            {
                var oldComponent = components[0];
                var newComponent = components[1];

                if (oldComponent.GetType() != newComponent.GetType())
                {
                    // All we have to do is change the Script field to the new type and Unity will immediately deserialize
                    // the existing data as that type, so any fields shared between both types will keep their data.

                    using (var serializedObject = new SerializedObject(oldComponent))
                    {
                        var scriptProperty = serializedObject.FindProperty("m_Script");
                        scriptProperty.objectReferenceValue = MonoScript.FromMonoBehaviour(newComponent);
                        serializedObject.ApplyModifiedProperties();
                    }
                }

                // Destroy all components other than the first (the oldest).
                EditorApplication.delayCall += () =>
                {
                    var i = 1;
                    for (; i < components.Length; i++)
                    {
                        Object.DestroyImmediate(components[i], true);
                    }
                };
            }
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Calls <see cref=" EditorApplication.delayCall"/> -= then += `method`.
        /// </summary>
        public static void EditorDelayCallOnce(EditorApplication.CallbackFunction method)
        {
            EditorApplication.delayCall -= method;
            EditorApplication.delayCall += method;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Registers the specified method to be called by the editor repeatedly at roughly the specified interval.
        /// </summary>
        public static EditorApplication.CallbackFunction EditorInvokeRepeating(Action method, double interval)
        {
            var nextCallTime = EditorApplication.timeSinceStartup + interval;

            EditorApplication.CallbackFunction update = delegate
            {
                if (EditorApplication.timeSinceStartup >= nextCallTime)
                {
                    method();
                    nextCallTime = EditorApplication.timeSinceStartup + interval;
                }
            };

            EditorApplication.update += update;
            return update;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Starts a coroutine to run in the editor update loop.
        /// The coroutine can be cancelled by removing the returned delegate from
        /// <see cref=" EditorApplication.update"/>.
        /// </summary>
        public static EditorApplication.CallbackFunction EditorStartCoroutine(IEnumerator coroutine)
        {
            EditorApplication.CallbackFunction update = null;

            update = delegate
            {
                if (!coroutine.MoveNext())
                    EditorApplication.update -= update;
            };

            EditorApplication.update += update;
            return update;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Draw the target and name of the specified <see cref="Delegate"/>.
        /// </summary>
        public static void DrawDelegate(Rect position, GUIContent label, Delegate del)
        {
            var width = position.width;

            position.xMax = EditorGUIUtility.labelWidth + 15;
            if (del.Target is Object obj)
            {
                // If the target is a Unity Object, draw it in an Object Field so the user can click to ping the object.

                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUI.ObjectField(position, obj, typeof(Object), true);
                }
            }
            else if (del.Method.DeclaringType.IsDefined(typeof(System.Runtime.CompilerServices.CompilerGeneratedAttribute), true))
            {
                // Anonymous Methods draw only their method name.

                position.width = width;

                GUI.Label(position, del.Method.GetNameCS());

                return;
            }
            else if (del.Target == null)
            {
                GUI.Label(position, del.Method.DeclaringType.GetNameCS());
            }
            else
            {
                GUI.Label(position, del.Target.ToString());
            }

            position.x += position.width;
            position.width = width - position.width;

            GUI.Label(position, del.Method.GetNameCS(CSharp.NameVerbosity.Name));
        }

        /************************************************************************************************************************/
        #region Assets
        /************************************************************************************************************************/

        /// <summary>
        /// Replaces each GUID in an array with the corresponding asset path using
        /// <see cref="AssetDatabase.GUIDToAssetPath"/>
        /// </summary>
        public static void GUIDsToAssetPaths(string[] guids)
        {
            for (int i = 0; i < guids.Length; i++)
                guids[i] = AssetDatabase.GUIDToAssetPath(guids[i]);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns an asset of the specified type from anywhere in the project.
        /// </summary>
        public static T FindAsset<T>() where T : Object
        {
            var filter = typeof(Component).IsAssignableFrom(typeof(T)) ?
                "t:GameObject" :
                "t:" + typeof(T).Name;

            var guids = AssetDatabase.FindAssets(filter);
            for (int i = 0; i < guids.Length; i++)
            {
                var assetPath = AssetDatabase.GUIDToAssetPath(guids[i]);
                var asset = AssetDatabase.LoadAssetAtPath<T>(assetPath);
                if (asset != null)
                    return asset;
            }

            return null;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns an asset of the specified type from anywhere in the project.
        /// Checks the `assetPathHint` before searching the rest of the project.
        /// </summary>
        public static T FindAsset<T>(string assetPathHint) where T : Object
        {
            var asset = AssetDatabase.LoadAssetAtPath<T>(assetPathHint);
            if (asset != null)
                return asset;

            return FindAsset<T>();
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Moves an asset from `oldPath` to `newPath` and deletes any empty directories at `oldPath`.
        /// </summary>
        public static void MoveAsset(string oldPath, string newPath, bool deleteEmptyDirectories = true)
        {
            // If the asset path changed, move the asset to maintain references.
            if (string.IsNullOrEmpty(oldPath) ||
                string.IsNullOrEmpty(newPath) ||
                oldPath == newPath)
                return;

            var asset = AssetDatabase.LoadAssetAtPath<Object>(oldPath);
            if (asset == null)
                return;

            Debug.Log("Asset moved from " + oldPath + " to " + newPath, asset);

            var newDirectory = Path.GetDirectoryName(newPath);
            if (!string.IsNullOrEmpty(newDirectory))
            {
                Directory.CreateDirectory(newDirectory);
                AssetDatabase.Refresh();
            }

            var error = AssetDatabase.MoveAsset(oldPath, newPath);
            if (!string.IsNullOrEmpty(error))
            {
                Debug.LogError(error);
                return;
            }

            if (deleteEmptyDirectories)
                DeleteEmptyDirectories(Path.GetDirectoryName(oldPath));
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Deletes the specified asset. If the asset's directory is then empty, it is deleted as well (recursively).
        /// </summary>
        public static void DeleteAsset(string assetPath, bool deleteEmptyDirectories = true)
        {
            AssetDatabase.DeleteAsset(assetPath);

            if (deleteEmptyDirectories)
                DeleteEmptyDirectories(Path.GetDirectoryName(assetPath));
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Deletes the specified directory if it is empty (ignoring metadata files), then does the same recursively
        /// for each parent directory. Refreshes the <see cref=" AssetDatabase"/> if anything was deleted.
        /// </summary>
        public static void DeleteEmptyDirectories(string path)
        {
            path = path.RemoveTrailingSlashes();

            AssetDatabase.StartAssetEditing();

            do
            {
                if (!AssetDatabase.IsValidFolder(path) ||
                    ContainsNonMetaFiles(path, out string[] _))
                    break;

                AssetDatabase.DeleteAsset(path);

                path = Path.GetDirectoryName(path);
            }
            while (path != null);

            AssetDatabase.StopAssetEditing();
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Checks if the specified directory contains any files which don't end with ".meta".
        /// </summary>
        public static bool ContainsNonMetaFiles(string directory, out string[] files)
        {
            files = Directory.GetFileSystemEntries(directory);

            for (int i = 0; i < files.Length; i++)
                if (!files[i].EndsWith(".meta"))
                    return true;

            return false;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Sub Assets
        /************************************************************************************************************************/

        /// <summary>
        /// [Editor-Only] After you save the scene object `obj` as an asset file and load it as `asset`, this method
        /// goes through all the serialized <see cref="Object"/> fields which weren't saved and adds them
        /// as sub-assets. Returns true if any sub-assets were saved.
        /// <para></para>
        /// For example, creating a procedural <see cref="Mesh"/>, assigning it to a <see cref="MeshFilter"/>, and
        /// saving the object as a prefab would not save the mesh anywhere unless you call this method or
        /// <see cref=" AssetDatabase.AddObjectToAsset(Object, Object)"/>.
        /// </summary>
        public static bool SaveSubAssets(Object obj, Object asset)
        {
            if (obj == null)
                throw new ArgumentNullException(nameof(obj));
            if (asset == null)
                throw new ArgumentNullException(nameof(asset));

            if (obj is Component component)
                obj = component.gameObject;

            var checkedObjects = Utils.GetDictionary<Object, bool>();
            var hasSubAssets = GatherSubAssets(obj, asset, checkedObjects);
            checkedObjects.Release();

            if (hasSubAssets)
            {
#if UNITY_2018_3_OR_NEWER
                // HACK: sub asset references don't get assigned properly in 2018.3+ otherwise.
                var gameObject = obj as GameObject;
                if (gameObject != null)
                {
                    var assetPath = AssetDatabase.GetAssetPath(asset);
                    PrefabUtility.SaveAsPrefabAsset(gameObject, assetPath, out var success);
                }
#endif

                AssetDatabase.ImportAsset(AssetDatabase.GetAssetPath(asset));
                return true;
            }
            else return false;
        }

        /************************************************************************************************************************/

        private static bool GatherSubAssets(Object target, Object asset, Dictionary<Object, bool> checkedObjects)
        {
            // checkedObjects contains objects mapped to a value indicating if they are sub assets.

            if (checkedObjects.ContainsKey(target))
                return false;

            checkedObjects.Add(target, false);

            if (!MightHaveSubAssets(target))
                return false;

            using (var serializedObject = new SerializedObject(target))
            {
                var targetProperty = serializedObject.GetIterator();
                if (!targetProperty.Next(true))
                    return false;

                using (var assetObject = new SerializedObject(asset))
                {
                    var modified = false;
                    var hasSubAssets = false;

                    do
                    {
                        if (targetProperty.propertyType != SerializedPropertyType.ObjectReference)
                            continue;

                        var obj = targetProperty.objectReferenceValue;
                        if (obj == null)
                            continue;

                        var assetProperty = assetObject.FindProperty(targetProperty.propertyPath);
                        if (assetProperty == null)
                            continue;

                        if (assetProperty.objectReferenceValue == null)
                        {
                            if (checkedObjects.TryGetValue(obj, out bool isSubAsset))
                            {
                                if (isSubAsset)
                                    goto ReAssignObject;
                                else
                                    continue;
                            }

                            if (obj is GameObject ||
                                obj is Component ||
                                 AssetDatabase.Contains(obj))
                                continue;

                            Utils.DebugLog("Saving Sub Asset: " + obj + " in asset: " + asset);

                            checkedObjects.Add(obj, true);

                            AssetDatabase.AddObjectToAsset(obj, asset);

                            ReAssignObject:
                            assetProperty.objectReferenceValue = obj;

                            modified = true;
                            hasSubAssets = true;
                        }
                        else
                        {
                            if (GatherSubAssets(obj, assetProperty.objectReferenceValue, checkedObjects))
                                hasSubAssets = true;
                        }
                    }
                    while (targetProperty.Next(true));

                    if (modified)
                        assetObject.ApplyModifiedPropertiesWithoutUndo();

                    return hasSubAssets;
                }
            }
        }

        /************************************************************************************************************************/

        private static bool MightHaveSubAssets(Object obj)
        {
            // Using a Dictionary for this increases the startup time without reducing the execution time. :(

            if (obj is GameObject ||
                obj is Transform ||
                obj is MonoBehaviour ||
                obj is ScriptableObject)
                return true;

            if (obj is Rigidbody ||
                obj is Rigidbody2D ||
                obj is Material ||
                obj is Texture ||
                obj is AudioClip ||
                obj is TextAsset ||
                obj is ParticleSystem ||
                obj is Mesh ||
                obj is PhysicMaterial ||
                obj is PhysicsMaterial2D ||
                obj is Sprite ||
                obj is RuntimeAnimatorController ||
                obj is Font ||
                obj is Flare ||
                obj is LightProbes ||
                obj is AssetBundle ||
                obj is AssetBundleManifest ||
                obj is RenderSettings ||
                obj is QualitySettings ||
                obj is Motion ||
                obj is BillboardAsset ||
                obj is LightmapSettings ||
                obj is AnimationClip ||
                obj is Avatar ||
                obj is TerrainData ||
                obj is Shader ||
                obj is ShaderVariantCollection ||
                obj is UnityEngine.Rendering.GraphicsSettings ||
                obj is UnityEngine.Audio.AudioMixer ||
                obj is UnityEngine.Audio.AudioMixerSnapshot ||
                obj is UnityEngine.Audio.AudioMixerGroup ||
                obj is AssetImporter ||
                obj is UnityEditor.Animations.AnimatorTransitionBase ||
                obj is UnityEditor.Animations.AnimatorState ||
                obj is UnityEditor.Animations.AnimatorStateMachine ||
                obj is AvatarMask ||
                obj is UnityEditor.Animations.BlendTree ||
                obj is DefaultAsset ||
                obj is Editor ||
                obj is EditorSettings ||
                obj is EditorUserSettings ||
                obj is EditorWindow ||
                obj is Tools ||
                obj is HumanTemplate ||
                obj is PlayerSettings ||
                obj is SceneAsset ||
                obj is LightingDataAsset ||
                obj is LightmapParameters)
                return false;

            return obj.GetType() != typeof(Object);
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Destroys all sub-assets which are part of the specified asset.</summary>
        public static void DestroySubAssets(string assetPath)
        {
            var subAssets = AssetDatabase.LoadAllAssetsAtPath(assetPath);
            for (int i = 0; i < subAssets.Length; i++)
            {
                var subAsset = subAssets[i];
                if (!(subAsset is Component) && !(subAsset is GameObject) && AssetDatabase.IsSubAsset(subAsset))
                {
                    Utils.DebugLog("Destroying sub asset " + subAsset);
                    Object.DestroyImmediate(subAsset, true);
                }
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Object Selection
        /************************************************************************************************************************/

        /// <summary>
        /// Selects `target` in the Unity Editor.
        /// </summary>
        public static void SelectObject(Object target)
        {
            if (Selection.activeObject != target)
            {
                Selection.activeObject = target;
            }
            else
            {
                Selection.activeObject = null;
                EditorApplication.delayCall += delegate
                {
                    Selection.activeObject = target;
                };
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Selects the specified asset in the Unity Editor.
        /// </summary>
        public static void SelectAsset(string assetPath)
        {
            if (assetPath == null)
                return;

            var asset = AssetDatabase.LoadAssetAtPath(assetPath, typeof(Object));

            if (asset == null)
            {
                assetPath = Utils.GetExistingParent(assetPath);
                asset = AssetDatabase.LoadAssetAtPath(assetPath, typeof(Object));
                if (asset == null)
                    return;
            }

            SelectObject(asset);

            // If the asset is a prefab, ping every instance of it in the scene.
            if (asset is GameObject)
            {
                var everything = Object.FindObjectsOfType(typeof(GameObject));
                for (int i = 0; i < everything.Length; i++)
                {
                    var obj = everything[i];
                    if (PrefabUtility.GetPrefabParent(obj) == asset)
                        EditorGUIUtility.PingObject(obj);
                }
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// If no file or directory exists at `path`, this method looks for the first parent directory which does exist.
        /// </summary>
        public static string GetExistingParent(string path)
        {
            if (!File.Exists(path) && !Directory.Exists(path))
            {
                while (true)
                {
                    path = Path.GetDirectoryName(path);
                    if (path == "")
                        return null;
                    else if (Directory.Exists(path))
                        break;
                }
            }

            return path;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
    }
}
