﻿// Kybernetik // Copyright 2019 Kybernetik //

using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Kybernetik
{
    /// <summary>A variety of miscellaneous utility methods.</summary>
    public static partial class Utils
    {
        /************************************************************************************************************************/
        #region Collections
        /************************************************************************************************************************/

        /// <summary>
        /// If the `array` is null or its length isn't equal to the specified `size` this method replaces it with a new
        /// array of that `size`. Unlike <see cref="Array.Resize"/> this method does not copy the elements from the old
        /// array into the new one.
        /// </summary>
        public static void SetSize<T>(ref T[] array, int size)
        {
            if (array == null || array.Length != size)
                array = new T[size];
        }

        /// <summary>
        /// If the `array` is null or its length isn't equal to the specified `size` this method allocates a new array
        /// of that `size`, otherwise it just returns the `array`. Unlike <see cref="Array.Resize"/> this method does
        /// not copy the elements from the old array into the new one.
        /// </summary>
        public static T[] SetSize<T>(T[] array, int size)
        {
            if (array == null || array.Length != size)
                array = new T[size];

            return array;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// If the dictionary contains a value for the given key, that value is returned.
        /// Otherwise the default value is returned.
        /// </summary>
        public static TValue Get<TKey, TValue>(this Dictionary<TKey, TValue> dictionary, TKey key, TValue defaultValue = default(TValue))
        {
            if (dictionary.TryGetValue(key, out TValue value))
                return value;
            else
                return defaultValue;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Removes and returns the last element in a list.
        /// </summary>
        public static T Pop<T>(this List<T> list)
        {
            var value = list[list.Count - 1];
            list.RemoveAt(list.Count - 1);
            return value;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Removes and returns the last element in a list or creates a new one if the list is empty.
        /// </summary>
        public static T PopLastOrCreate<T>(this List<T> list) where T : new()
        {
            if (list.Count > 0)
            {
                var value = list[list.Count - 1];
                list.RemoveAt(list.Count - 1);
                return value;
            }
            else return new T();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns a copy of `array` with `element` inserted at `index`.
        /// </summary>
        public static T[] InsertAt<T>(this T[] array, int index, T element)
        {
            if (array != null && array.Length > 0)
            {
                // Create new array.
                var newArray = new T[array.Length + 1];

                // Copy from the start of the old array up to the index where you are inserting the new element.
                Array.Copy(array, newArray, index);

                // Assign the new element at the desired index.
                newArray[index] = element;

                // Copy the rest of the old array after the new element.
                if (index < array.Length) Array.Copy(array, index, newArray, index + 1, array.Length - index);

                return newArray;
            }
            else
            {
                return new T[] { element };
            }
        }

        /// <summary>
        /// Returns a copy of `array` with `element` inserted at the end.
        /// </summary>
        public static T[] InsertAt<T>(this T[] array, T element)
        {
            if (array != null && array.Length > 0)
            {
                return array.InsertAt(array.Length, element);
            }
            else
            {
                return new T[] { element };
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns a copy of `array` with the element at `index` removed.
        /// </summary>
        public static T[] RemoveAt<T>(this T[] array, int index)
        {
            // Create new arrays.
            var newArray = new T[array.Length - 1];

            // Copy from the start of the old array up to the target index.
            Array.Copy(array, newArray, index);

            // Skip over that index and copy the rest after that.
            Array.Copy(array, index + 1, newArray, index, newArray.Length - index);

            return newArray;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// If `collection` doesn't already contain `value`, this method adds it and returns true.
        /// </summary>
        public static bool AddIfNew<T>(this ICollection<T> collection, T value)
        {
            if (!collection.Contains(value))
            {
                collection.Add(value);
                return true;
            }
            else return false;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Sorts `list`, maintaining the order of any elements with an identical comparison
        /// (unlike the standard <see cref="List{T}.Sort(Comparison{T})"/> method).
        /// </summary>
        public static void StableInsertionSort<T>(IList<T> list, Comparison<T> comparison)
        {
            var count = list.Count;
            for (int j = 1; j < count; j++)
            {
                var key = list[j];

                var i = j - 1;
                for (; i >= 0 && comparison(list[i], key) > 0; i--)
                {
                    list[i + 1] = list[i];
                }
                list[i + 1] = key;
            }
        }

        /// <summary>
        /// Sorts `list`, maintaining the order of any elements with an identical comparison
        /// (unlike the standard <see cref="List{T}.Sort()"/> method).
        /// </summary>
        public static void StableInsertionSort<T>(IList<T> list) where T : IComparable<T>
        {
            StableInsertionSort(list, (a, b) => a.CompareTo(b));
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Inserts a new value into a sorted list.
        /// </summary>
        public static void InsertSorted<T>(List<T> list, T item, IComparer<T> comparer)
        {
            if (list.Count == 0)
            {
                // Simple add.
                list.Add(item);
            }
            else if (comparer.Compare(item, list[list.Count - 1]) >= 0)
            {
                // Add to the end as the item being added is greater than the last item by comparison.
                list.Add(item);
            }
            else if (comparer.Compare(item, list[0]) <= 0)
            {
                // Add to the start as the item being added is less than the first item by comparison.
                list.Insert(0, item);
            }
            else
            {
                // Otherwise, search for the place to insert.
                var index = list.BinarySearch(item, comparer);
                if (index < 0)
                {
                    // The zero-based index of item if item is found;
                    // otherwise, a negative number that is the bitwise complement of the index of the next element
                    // that is larger than item or, if there is no larger element, the bitwise complement of Count.
                    index = ~index;
                }

                list.Insert(index, item);
            }
        }
        /************************************************************************************************************************/

        /// <summary>
        /// If the <see cref="List{T}.Capacity"/> is less than the specified value, it is increased to that value.
        /// </summary>
        public static void RequireCapacity<T>(this List<T> list, int minCapacity)
        {
            if (list.Capacity < minCapacity)
                list.Capacity = minCapacity;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Adds or removes items to bring the <see cref="List{T}.Count"/> equal to the specified `count`.
        /// </summary>
        public static void SetCount<T>(List<T> list, int count)
        {
            if (count > list.Count)
            {
                list.Capacity = count;

                count -= list.Count;
                while (count-- > 0)
                    list.Add(default(T));
            }
            else
            {
                list.RemoveRange(count, list.Count - count);
            }
        }

        /************************************************************************************************************************/
        #region Log Error If Modified
        /************************************************************************************************************************/

        /// <summary>
        /// Logs an error if the `collection` is modified after calling this method.
        /// <para></para>
        /// One collection will be checked every update (in the editor or at runtime), and all collections will be checked when this assembly
        /// is unloaded.
        /// <para></para>
        /// Can be cancelled by <see cref="CancelLogErrorIfModified"/>.
        /// </summary>
        public static void LogErrorIfModified(this IEnumerable collection, string name)
        {
            if (collection == null)
                return;

            Utils.LogCallerIfRestricted();

            var enumerator = collection.GetEnumerator();
            CollectionModificationChecker.Collections.Add(collection);
            CollectionModificationChecker.Enumerators.Add(enumerator);
            CollectionModificationChecker.Names.Add(name);

            var duplicateCollection = new List<object>();
            while (enumerator.MoveNext())
                duplicateCollection.Add(enumerator.Current);
            CollectionModificationChecker.DuplicateEnumerators.Add(duplicateCollection.GetEnumerator());
        }

        /************************************************************************************************************************/

        /// <summary>[Debug-Conditional]
        /// Logs an error if the `collection` is modified after calling this method.
        /// <para></para>
        /// One collection will be checked every update (in the editor or at runtime), and all collections will be checked when this assembly
        /// is unloaded.
        /// <para></para>
        /// Can be cancelled by <see cref="CancelLogErrorIfModified"/>.
        /// </summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugLogErrorIfModified(this IEnumerable collection, string name)
        {
            LogErrorIfModified(collection, name);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Cancels a previous call to <see cref="LogErrorIfModified"/>.
        /// </summary>
        public static void CancelLogErrorIfModified(this IEnumerable collection)
        {
            var index = CollectionModificationChecker.Collections.IndexOf(collection);
            if (index >= 0)
                CollectionModificationChecker.RemoveAt(index);
        }

        /************************************************************************************************************************/

        private sealed class CollectionModificationChecker
#if !UNITY_EDITOR
            : MonoBehaviour
#endif
        {
            /************************************************************************************************************************/

            public static readonly List<IEnumerable> Collections = new List<IEnumerable>();
            public static readonly List<IEnumerator> Enumerators = new List<IEnumerator>();
            public static readonly List<IEnumerator> DuplicateEnumerators = new List<IEnumerator>();
            public static readonly List<string> Names = new List<string>();

            private static readonly CollectionModificationChecker Instance;

            private static int _CurrentIndex;

            /************************************************************************************************************************/

            static CollectionModificationChecker()
            {
#if UNITY_EDITOR

                Instance = new CollectionModificationChecker();
                UnityEditor.EditorApplication.update += CheckNext;

#else

                Utils.LogCallerIfRestricted();

                var go = new GameObject(nameof(CollectionModificationChecker));
                DontDestroyOnLoad(go);
                go.hideFlags = HideFlags.HideAndDontSave;
                Instance = go.AddComponent<CollectionModificationChecker>();

#endif
            }

            /************************************************************************************************************************/

            private static void CheckNext()
            {
                if (Enumerators.Count == 0)
                    return;

                if (_CurrentIndex >= Enumerators.Count)
                    _CurrentIndex = 0;

                if (!CheckIfModified(_CurrentIndex))
                    _CurrentIndex++;
            }

            /************************************************************************************************************************/

#if !UNITY_EDITOR
            private void Update()
            {
                CheckNext();
            }
#endif

            /************************************************************************************************************************/

            private static bool CheckIfModified(int index)
            {
                try
                {
                    var enumerator = Enumerators[index];
                    var duplicateEnumerator = DuplicateEnumerators[index];
                    enumerator.Reset();
                    duplicateEnumerator.Reset();

                    while (enumerator.MoveNext())
                    {
                        if (!duplicateEnumerator.MoveNext() ||
                            !Equals(enumerator.Current, duplicateEnumerator.Current))
                        {
                            goto HasBeenModified;
                        }
                    }

                    return false;
                }
                catch { }

                HasBeenModified:
                Debug.LogError("Collection has been modified: " + Names[index] +
                    ". Do not modify it after " + typeof(Utils).GetNameCS() + "." + nameof(LogErrorIfModified) + " has been called.");

                try
                {
                    DuplicateEnumerators[index].Reset();
                    Debug.LogError("Original: " + DeepToString(DuplicateEnumerators[index]));
                    Debug.LogError("Current: " + DeepToString(Collections[index]));
                }
                catch { }

                RemoveAt(index);
                return true;
            }

            /************************************************************************************************************************/

            internal static void RemoveAt(int index)
            {
                Collections.RemoveAt(index);
                Enumerators.RemoveAt(index);
                DuplicateEnumerators.RemoveAt(index);
                Names.RemoveAt(index);
            }

            /************************************************************************************************************************/

            private CollectionModificationChecker() { }

            ~CollectionModificationChecker()
            {
                for (int i = Enumerators.Count - 1; i >= 0; i--)
                    CheckIfModified(i);
            }

            /************************************************************************************************************************/
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Enums
        /************************************************************************************************************************/

        /// <summary>Returns 'T'.`obj.ToString()`. Useful for enums.</summary>
        public static string FriendlyFullName<T>(T obj)
        {
            var text = GetStringBuilder();
            AppendFriendlyFullName(text, obj);
            return text.ReleaseToString();
        }

        /// <summary>Appends 'Type'.`obj.ToString()`. Useful for enums.</summary>
        public static void AppendFriendlyFullName<T>(StringBuilder text, T obj)
        {
            text.Append(typeof(T).GetNameCS());

            if (obj == null)
                text.Append(".null");
            else
                text.Append('.').Append(obj);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Caches and simplifies access to the internals of an enum type.
        /// Do not use on non-enum types.
        /// </summary>
        public static class EnumCache<T> where T : struct
        {
            /************************************************************************************************************************/

            static EnumCache()
            {
                Utils.EditorAssert(typeof(T).IsEnum, () =>
                    typeof(T).GetNameCS() + "should not be used in " + typeof(EnumCache<T>).GetNameCS() + " because it is not an enum type.");
            }

            /************************************************************************************************************************/

            /// <summary>An array of all the enum's values retrieved using <see cref="Enum.GetValues"/>.</summary>
            public static readonly T[] Values = (T[])Enum.GetValues(typeof(T));

            private static ulong[] _MaskValues;

            /// <summary>An array of all the enum's values converted to unsigned longs to allow bitwise operations.</summary>
            public static ulong[] MaskValues
            {
                get
                {
                    if (_MaskValues == null)
                    {
                        _MaskValues = new ulong[Values.Length];
                        for (int i = 0; i < _MaskValues.Length; i++)
                            _MaskValues[i] = Convert.ToUInt64(Values[i]);
                    }

                    return _MaskValues;
                }
            }

            /************************************************************************************************************************/

            /// <summary>
            /// Returns an array containing the name of each value in the enum.
            /// Also includes the tooltip of any values with a <see cref="TooltipAttribute"/>.
            /// </summary>
            public static GUIContent[] GetGUIContents()
            {
                var contents = new GUIContent[Values.Length];
                for (int i = 0; i < contents.Length; i++)
                {
                    var content = new GUIContent(Values[i].ToString());
                    contents[i] = content;

                    var members = typeof(T).GetMember(content.text);
                    if (members.Length == 0)
                        continue;

                    var member = members[0];
                    var tooltip = member.GetCustomAttribute<TooltipAttribute>();
                    if (tooltip != null)
                        content.tooltip = tooltip.tooltip;

                }
                return contents;
            }

            /************************************************************************************************************************/
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Get a list of all the individual flags in `value`.
        /// </summary>
        public static List<T> GetFlags<T>(T value) where T : struct
        {
            var bits = Convert.ToUInt64(value);
            var results = Utils.GetList<T>();
            for (int i = EnumCache<T>.Values.Length - 1; i >= 0; i--)
            {
                var mask = EnumCache<T>.MaskValues[i];

                if (i == 0 && mask == 0)
                    break;

                if ((bits & mask) == mask)
                {
                    results.Add(EnumCache<T>.Values[i]);
                    bits -= mask;
                }
            }

            return results;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Get a list of all the enum values contained in `value`.
        /// </summary>
        public static List<T> GetFlagsFull<T>(T value) where T : struct
        {
            var bits = Convert.ToUInt64(value);
            var results = Utils.GetList<T>();
            for (int i = EnumCache<T>.Values.Length - 1; i >= 0; i--)
            {
                var mask = EnumCache<T>.MaskValues[i];

                // Only include the zero value if there is nothing else.
                if (mask == 0 && results.Count > 0)
                    continue;

                if ((bits & mask) == mask)
                {
                    results.Add(EnumCache<T>.Values[i]);
                }
            }

            return results;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends all the enum values contained in `value`.
        /// </summary>
        public static void AppendFlagsFull<T>(StringBuilder text, T value, bool fullTypeName) where T : struct
        {
            var flags = GetFlagsFull(value);

            var typeName = fullTypeName ? typeof(T).GetNameCS() : typeof(T).Name;

            text.Append(typeName).Append(".").Append(flags[0]);
            for (int i = 1; i < flags.Count; i++)
                text.Append(" | ").Append(typeName).Append(".").Append(flags[i]);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Misc
        /************************************************************************************************************************/

        /// <summary>
        /// Exposes a method to be called when a new instance is created by <see cref="EnsureExists"/>.
        /// </summary>
        public interface IOnCreate
        {
            /// <summary>
            /// Called when a new instance of the implementing type is created by <see cref="EnsureExists"/>.
            /// </summary>
            void OnCreate();
        }

        /// <summary>
        /// If `obj` is null this method assigns a new instance to it and calls <see cref="IOnCreate.OnCreate"/>.
        /// </summary>
        public static void EnsureExists<T>(ref T obj) where T : class, IOnCreate, new()
        {
            if (obj == null)
            {
                obj = new T();
                obj.OnCreate();
            }
        }

        /************************************************************************************************************************/

        /// <summary>Disables member renaming in an [<see cref="ObfuscationAttribute"/>].</summary>
        public const string NoRename = "-rename";

        /************************************************************************************************************************/

        /// <summary>
        /// Re-scales `value` from the old range (`oldMin` to `oldMax`) to the new range (0 to 1).
        /// </summary>
        public static float LinearRescaleTo01(this float value, float oldMin, float oldMax)
        {
            if (oldMin != oldMax)
                return (value - oldMin) / (oldMax - oldMin);
            else
                return 0.5f;
        }

        /// <summary>
        /// Re-scales `value` from the old range (`oldMin` to `oldMax`) to the new range (`newMin` to `newMax`).
        /// </summary>
        public static float LinearRescale(this float value, float oldMin, float oldmax, float newMin, float newmax)
        {
            return value.LinearRescaleTo01(oldMin, oldmax) * (newmax - newMin) + newMin;
        }

        /// <summary>
        /// Re-scales `value` from the old range (`oldMin` to `oldMax`) to the new range (`newMin` to `newMax`) and
        /// clamps it within that range.
        /// </summary>
        public static float LinearRescaleClamped(this float value, float oldMin, float oldmax, float newMin, float newmax)
        {
            return Mathf.Clamp01(value.LinearRescaleTo01(oldMin, oldmax)) * (newmax - newMin) + newMin;
        }

        /************************************************************************************************************************/

        /// <summary>Creates a new email with the system's default email application.</summary>
        public static void CreateNewEmail(string address, string subject, string body)
        {
            subject = EscapeURL(subject);
            body = EscapeURL(body);

            Application.OpenURL("mailto:" + address + "? subject=" + subject + "&body=" + body);
        }

        private static string EscapeURL(string url)
        {
            return WWW.EscapeURL(url).Replace("+", "%20");
        }

        /************************************************************************************************************************/
        #region References
        /************************************************************************************************************************/

        /// <summary>Swaps the references `a` and `b`.</summary>
        public static void Swap<T>(ref T a, ref T b)
        {
            var temp = a;
            a = b;
            b = temp;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Sets the reference to its default value (null for reference types) and returns the original value.
        /// </summary>
        public static T Nullify<T>(ref T obj)
        {
            var temp = obj;
            obj = default(T);
            return temp;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns true and sets `currentValue` if `newValue` is different.
        /// </summary>
        public static bool SetValue<T>(ref T currentValue, T newValue) where T : struct
        {
            if (currentValue.Equals(newValue))
                return false;

            currentValue = newValue;
            return true;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Checks and sets `currentValue` if `newValue` is different.
        /// </summary>
        public static bool SetReference<T>(ref T currentValue, T newValue) where T : class
        {
            if (currentValue == null)
            {
                if (newValue == null) return false;
            }
            else
            {
                if (currentValue.Equals(newValue)) return false;
            }

            currentValue = newValue;
            return true;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Unity
        /************************************************************************************************************************/
        #region Logging
        /************************************************************************************************************************/

        /// <summary>Logs an error message stating that `value` is not a valid T. Useful for enums.</summary>
        public static void LogInvalidValue<T>(T value)
        {
            Debug.LogError(value + " is not a valid " + typeof(T).GetNameCS());
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Conditional] <code>if (!condition) Debug.LogWarning(message)</code></summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorAssertWarning(bool condition, object message)
        {
            if (!condition)
                Debug.LogWarning(message);
        }

        /// <summary>[Editor-Conditional] <code>if (!condition) Debug.LogError(message)</code></summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorAssert(bool condition, object message)
        {
            if (!condition)
                Debug.LogError(message);
        }

        /// <summary>[Editor-Conditional] <code>if (!condition) Debug.LogError(message, context)</code></summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorAssert(bool condition, object message, Object context)
        {
            if (!condition)
                Debug.LogError(message, context);
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Conditional]
        /// <code>if (!condition) Debug.LogWarning(getMessage())</code>
        /// This allows you to avoid building the message string when the assertion passes.
        /// </summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorAssertWarning(bool condition, Func<object> getMessage)
        {
            if (!condition)
                Debug.LogWarning(getMessage());
        }

        /// <summary>[Editor-Conditional]
        /// <code>if (!condition) Debug.LogError(getMessage())</code>
        /// This allows you to avoid building the message when the assertion passes.
        /// </summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorAssert(bool condition, Func<object> getMessage)
        {
            if (!condition)
                Debug.LogError(getMessage());
        }

        /// <summary>[Editor-Conditional]
        /// <code>if (!condition) Debug.LogError(getMessage(), context)</code>
        /// This allows you to avoid building the message when the assertion passes.
        /// </summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorAssert(bool condition, Func<object> getMessage, Object context)
        {
            if (!condition)
                Debug.LogError(getMessage(), context);
        }

        /************************************************************************************************************************/

        /// <summary>[Debug-Conditional] <code>Debug.Log(message)</code></summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugLog(object message)
        {
            Debug.Log(message);
        }

        /// <summary>[Debug-Conditional] <code>Debug.LogWarning(message)</code></summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugLogWarning(object message)
        {
            Debug.LogWarning(message);
        }

        /// <summary>[Debug-Conditional] <code>Debug.LogError(message)</code></summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugLogError(object message)
        {
            Debug.LogError(message);
        }

        /// <summary>[Debug-Conditional] <code>if (!condition) Debug.LogError(message)</code></summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugAssert(bool condition, object message)
        {
            if (!condition)
                Debug.LogError(message);
        }

        /// <summary>[Debug-Conditional] <code>if (!condition) Debug.LogWarning(message)</code></summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugAssertWarning(bool condition, object message)
        {
            if (!condition)
                Debug.LogWarning(message);
        }

        /// <summary>[Debug-Conditional] <code>if (!condition) Debug.Log(message)</code></summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugAssertLog(bool condition, object message)
        {
            if (!condition)
                Debug.Log(message);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// If RESTRICT_USAGE is defined, this method will log the name of the calling method. This is useful for
        /// verifying that certain methods are only used in certain contexts. For example, you might want to ensure
        /// that an inefficient method or class is not used in a release build of your application.
        /// </summary>
        [System.Diagnostics.Conditional("RESTRICT_USAGE")]
        public static void LogCallerIfRestricted()
        {
            var text = GetStringBuilder();
            text.Append(new System.Diagnostics.StackFrame(1).GetMethod().GetNameCS());
            text.Append(" was called while RESTRICT_USAGE is defined.");
            Debug.LogWarning(text.ReleaseToString());
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Conditional] Asserts that a pair of collections are not null and have the same count.</summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorAssertSameSize(ICollection a, ICollection b)
        {
            EditorAssert(
                a != null && b != null && a.Count == b.Count,
                "Collections are null or have different lengths");
        }

        /************************************************************************************************************************/
        #region Limited Log
        /************************************************************************************************************************/

        /// <summary>
        /// Calls <code>Debug.Log(message)</code> until the `maximumCallCount` has been exceeded by the caller, after
        /// which this method does nothing.
        /// </summary>
        public static void LogLimited(object message, int maximumCallCount = 1)
        {
            var caller = new System.Diagnostics.StackFrame(1).GetMethod();

            LogCounter.CallCounts.TryGetValue(caller, out int callCount);

            if (callCount < maximumCallCount)
            {
                LogCounter.CallCounts[caller] = callCount + 1;
                Debug.Log(message);
            }
        }

        /// <summary>
        /// Calls <code>Debug.Log(message, context)</code> until the `maximumCallCount` has been exceeded by the
        /// caller, after which this method does nothing.
        /// </summary>
        public static void LogLimited(object message, Object context, int maximumCallCount = 1)
        {
            var caller = new System.Diagnostics.StackFrame(1).GetMethod();

            LogCounter.CallCounts.TryGetValue(caller, out int callCount);

            if (callCount < maximumCallCount)
            {
                LogCounter.CallCounts[caller] = callCount + 1;
                Debug.Log(message, context);
            }
        }

        /************************************************************************************************************************/

        private static class LogCounter
        {
            public static readonly Dictionary<MethodBase, int>
                CallCounts = new Dictionary<MethodBase, int>();
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        /// <summary>
        /// Gets an instance of the specified component type on a game object or adds one if it doesn't have one.
        /// </summary>
        /// <typeparam name="T">The type of component to get.</typeparam>
        /// <param name="go">The game object to get it from.</param>
        /// <returns>The component that was found or added.</returns>
        public static T GetOrAddComponent<T>(this GameObject go) where T : Component
        {
            var component = go.GetComponent<T>();
            if (component == null)
                return go.AddComponent<T>();
            else
                return component;
        }

        /************************************************************************************************************************/

        /// <summary>Returns a string containing the hexadecimal representation of `color`.</summary>
        public static string ColorToHex(Color32 color)
        {
            var text = Utils.GetStringBuilder();
            AppendColorToHex(text, color);
            return text.ReleaseToString();
        }

        /// <summary>Appends the hexadecimal representation of `color`.</summary>
        public static void AppendColorToHex(StringBuilder text, Color32 color)
        {
            text.Append(color.r.ToString("X2"));
            text.Append(color.g.ToString("X2"));
            text.Append(color.b.ToString("X2"));
            text.Append(color.a.ToString("X2"));
        }

        /************************************************************************************************************************/

        /// <summary>Appends the a rich text color tag around `message`.</summary>
        public static void AppendColorTag(StringBuilder text, Color32 color, string message)
        {
            text.Append("<color=#");
            Utils.AppendColorToHex(text, color);
            text.Append('>');
            text.Append(message);
            text.Append("</color>");
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Sets <code>transform.hideFlags = flags</code> and does the same for all the children of `transform`.
        /// </summary>
        public static void SetHideFlagsRecursive(Transform transform, HideFlags flags)
        {
            transform.gameObject.hideFlags = flags;

            for (int i = 0; i < transform.childCount; i++)
            {
                SetHideFlagsRecursive(transform.GetChild(i), flags);
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Truncate the given string so it can fit in a GUI label.
        /// MaxLength = 16,382.
        /// </summary>
        public static string TruncateForLabel(string text)
        {
            const int MaxLength = 16382;// 16384 is a power of 2.
            if (text.Length > MaxLength)
                return text.Substring(0, MaxLength);
            else
                return text;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Combines two textures into one. The `top` texture is alpha-blended onto the `bottom`.
        /// </summary>
        /// <param name="bottom">The base texture to start with.</param>
        /// <param name="top">The texture to alpha-blend onto the `bottom`</param>
        /// <param name="border">The edges of the `top` texture are scaled down by this value.</param>
        public static Texture CombineTextures(Texture bottom, Texture top, float border)
        {
            if (bottom == null)
                return top;

            if (top == null)
                return bottom;

            GL.PushMatrix();
            GL.LoadPixelMatrix(-border, 1 + border, 1 + border, -border);

            var screenRect = new Rect(0, 0, 1, 1);

            var combined = new RenderTexture(top.width, top.height, 0);
            RenderTexture.active = combined;

            Graphics.Blit(bottom, combined);
            Graphics.DrawTexture(screenRect, top);

            RenderTexture.active = null;

            GL.PopMatrix();
            return combined;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}
