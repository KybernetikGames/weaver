﻿// Kybernetik // Copyright 2019 Kybernetik //

//#define UNIT_TEST

#if UNIT_TEST
#warning Disable Unit Tests when not in use.

using System;
using System.Collections.Generic;
using System.Reflection;

namespace Kybernetik
{
    /// <summary>
    /// Automatically executes an attributed method as a Unit Test whenever assemblies are reloaded.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = false)]
#if UNITY_EDITOR
    [UnityEditor.InitializeOnLoad]
#endif
    public sealed class UnitTest : Attribute
    {
        /************************************************************************************************************************/
#if UNITY_EDITOR
        static UnitTest()
        {
            UnityEditor.EditorApplication.delayCall += ExecuteTests;
        }
#endif
        /************************************************************************************************************************/

#if UNITY_EDITOR
        [UnityEditor.MenuItem("Window/Kybernetik/Execute Unit Tests")]
#endif
        private static void ExecuteTests()
        {
            List<UnitTest> attributes = new List<UnitTest>();
            List<MethodInfo> methods = new List<MethodInfo>();
            Reflection.GetAttributedMethods(Reflection.StaticBindings, attributes, methods);

            if (methods.Count == 0)
            {
                Debug.LogWarning("No Unit Tests were found. You should recompile Kybernetik.Core.dll when not using Unit Tests.");
                return;
            }

            Debug.Log("<B>Executing Unit Tests</B>");

            for (int i = 0; i < methods.Count; i++)
            {
                MethodInfo method = methods[i];
                try
                {
                    Utils.EditorTimer.Start();
                    method.Invoke(null, null);
                    Debug.Log("<B>" + method.GetNameCS() + "</B>: Pass (" + Utils.EditorTimer.Stop() + "s)");
                }
                catch (Exception ex)
                {
                    if (ex.InnerException != null)
                        ex = ex.InnerException;

                    Debug.LogError("<B>" + method.GetNameCS() + "</B>: " + ex);
                    Utils.EditorTimer.Stop();
                }
            }

            Debug.Log("<B>Finished Unit Tests</B>");
        }

        /************************************************************************************************************************/

        /// <summary>An exception that indicates the failure of a <see cref="UnitTest"/>.</summary>
        public sealed class FailureException : Exception
        {
            /// <summary>Constructs a new <see cref="FailureException"/> with the specified `message`.</summary>
            public FailureException(string message) : base(message) { }

            /// <summary>Returns a string containing the exception message followed by the stack trace.</summary>
            public override string ToString() => Message + "\n" + StackTrace;
        }

        /************************************************************************************************************************/
    }
}

#endif
