﻿// Kybernetik // Copyright 2019 Kybernetik //

#if UNITY_EDITOR

using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Kybernetik
{
    /// <summary>A variety of utility methods relating to script assets in Unity.</summary>
    public static class UnityScripts
    {
        /************************************************************************************************************************/
#region Script Details
        /************************************************************************************************************************/

        private static Dictionary<Type, MonoScript> _Scripts;

        /// <summary>
        /// Tries to get the script asset containing `type`.
        /// </summary>
        public static MonoScript GetScript(Type type)
        {
            MonoScript script;

            if (_Scripts == null)
            {
                var scripts = MonoImporter.GetAllRuntimeMonoScripts();
                _Scripts = new Dictionary<Type, MonoScript>(scripts.Length);
                for (int i = 0; i < scripts.Length; i++)
                {
                    script = scripts[i];
                    var scriptClass = script.GetClass();
                    if (scriptClass != null && !_Scripts.ContainsKey(scriptClass))
                        _Scripts.Add(scriptClass, script);
                }
            }

            var rootType = type;
            while (rootType.DeclaringType != null)
                rootType = rootType.DeclaringType;

            _Scripts.TryGetValue(rootType, out script);
            return script;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Tries to get the path to the script asset containing `type`. If this fails, it instead gets the path to its
        /// assembly.
        /// </summary>
        public static string GetSourcePath(Type type, out bool isScript)
        {
            var script = GetScript(type);
            if (script != null)
            {
                isScript = true;
                return AssetDatabase.GetAssetPath(script);
            }
            else
            {
                isScript = false;
                return type.Assembly.Location.ReplaceSlashesForward();
            }
        }

        /************************************************************************************************************************/

        private static Dictionary<Type, int> _ExecutionTimes;

        /// <summary>
        /// Tries to get the execution time of the script asset containing `type`.
        /// </summary>
        public static int GetExecutionTime(Type type)
        {
            if (_ExecutionTimes == null)
                _ExecutionTimes = new Dictionary<Type, int>();

            if (!_ExecutionTimes.TryGetValue(type, out var executionTime))
            {
                var script = GetScript(type);
                if (script != null)
                    executionTime = MonoImporter.GetExecutionOrder(script);

                _ExecutionTimes.Add(type, executionTime);
            }

            return executionTime;
        }

        /************************************************************************************************************************/
#endregion
        /************************************************************************************************************************/
#region Custom Defines
        /************************************************************************************************************************/

        /// <summary>
        /// Defines the specified symbol for the current build platform in the Unity Project Settings.
        /// </summary>
        public static void Define(string symbol)
        {
            Define(symbol, EditorUserBuildSettings.selectedBuildTargetGroup);
        }

        /// <summary>
        /// Defines the specified symbol for the specified platform in the Unity Project Settings.
        /// </summary>
        public static void Define(string symbol, BuildTargetGroup platform)
        {
            var defines = PlayerSettings.GetScriptingDefineSymbolsForGroup(platform);

            if (!IsDefined(defines, symbol, out var index))
            {
                if (defines.Length > 0)
                    defines += ";";

                defines += symbol;

                PlayerSettings.SetScriptingDefineSymbolsForGroup(platform, defines);
                Debug.Log("Added custom define \"" + symbol + "\" to " + platform);
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Undefines the specified symbol from all build platforms in the Unity Project Settings.
        /// </summary>
        public static void Undefine(string symbol)
        {
            var platforms = Utils.EnumCache<BuildTargetGroup>.Values;

            for (int i = 0; i < platforms.Length; i++)
                Undefine(symbol, platforms[i]);
        }

        /// <summary>
        /// Undefines the specified symbol from the specified platform in the Unity Project Settings.
        /// </summary>
        public static void Undefine(string symbol, BuildTargetGroup platform)
        {
            var defines = PlayerSettings.GetScriptingDefineSymbolsForGroup(platform);

            if (IsDefined(defines, symbol, out var index))
            {
                // Remove the custom define and its semicolon.
                var count = symbol.Length;

                if (index > 0)
                {
                    index--;// Left semicolon.
                    count++;
                }
                else if (index + count < defines.Length)
                {
                    count++;// Right semicolon.
                }

                defines = defines.Remove(index, count);

                PlayerSettings.SetScriptingDefineSymbolsForGroup(platform, defines);

                Debug.Log("Removed custom define \"" + symbol + "\" from " + platform);
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Checks if the specified symbol is defined for the current build platform in the Unity Project Settings.
        /// </summary>
        public static bool IsDefined(string symbol)
        {
            return IsDefined(symbol, EditorUserBuildSettings.selectedBuildTargetGroup);
        }

        /// <summary>
        /// Checks if the specified symbol is defined for the specified platform in the Unity Project Settings.
        /// </summary>
        public static bool IsDefined(string symbol, BuildTargetGroup platform)
        {
            var defines = PlayerSettings.GetScriptingDefineSymbolsForGroup(platform);

            return IsDefined(defines, symbol, out var index);
        }

        /// <summary>
        /// Checks if `defines` contains `symbol`, separated from other symbols by a semicolon.
        /// </summary>
        public static bool IsDefined(string defines, string symbol, out int index)
        {
            index = -1;
            while (true)
            {
                index = defines.IndexOf(symbol, index + 1);
                if (index < 0)
                    return false;

                if (index > 0 && defines[index - 1] != ';')
                    continue;

                var end = index + symbol.Length;
                if (end < defines.Length && defines[end] != ';')
                {
                    index = end;
                    continue;
                }

                return true;
            }
        }

        /************************************************************************************************************************/
#endregion
        /************************************************************************************************************************/
    }
}

#endif
