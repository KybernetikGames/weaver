﻿// Kybernetik // Copyright 2019 Kybernetik //

#if UNITY_EDITOR

using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using Debug = UnityEngine.Debug;
using Object = UnityEngine.Object;

namespace Kybernetik
{
    /// <summary>[Editor-Only]
    /// A component that uses a custom <see cref="Action"/> to draw the inspector.
    /// </summary>
    [AddComponentMenu("")]
    public sealed class CustomInspector : MonoBehaviour
    {
        /************************************************************************************************************************/

        /// <summary>
        /// The target object that this inspector is for.
        /// It is passed into the inspector GUI delegate.
        /// This inspector will stop drawing if the target is garbage collected.
        /// </summary>
        public WeakReference Target { get; private set; }

        /// <summary>
        /// A callback to return a delegate from the <see cref="Target"/> that draws the inspector.
        /// This extra layer of abstraction ensures that this inspector doesn't hold a direct reference to the target
        /// so it can be garbage collected naturally.
        /// </summary>
        public Func<object, Action> GetInspectorGUI { get; private set; }

        /************************************************************************************************************************/

        /// <summary>
        /// Adds a <see cref="CustomInspector"/> to the `gameobject` with the specified parameters.
        /// </summary>
        public static void Create(GameObject gameObject, object target, Func<object, Action> getInspectorGUI)
        {
            var inspector = gameObject.AddComponent<CustomInspector>();
            inspector.Target = new WeakReference(target);
            inspector.GetInspectorGUI = getInspectorGUI;
        }

        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/

    [CustomEditor(typeof(CustomInspector))]
    internal sealed class CustomInspectorEditor : Editor
    {
        /************************************************************************************************************************/

        public override void OnInspectorGUI()
        {
            var inspector = target as CustomInspector;

            if (inspector.Target == null)
            {
                GUILayout.Label("No target has been assigned");
                return;
            }

            if (!inspector.Target.IsAlive)
            {
                GUILayout.Label("Target has been garbage collected");
            }

            inspector.GetInspectorGUI(inspector.Target.Target).Invoke();
        }

        /************************************************************************************************************************/
    }
}

#endif
