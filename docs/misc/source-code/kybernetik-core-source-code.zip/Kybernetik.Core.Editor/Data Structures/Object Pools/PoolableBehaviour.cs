// Kybernetik // Copyright 2019 Kybernetik //

using UnityEngine;

namespace Kybernetik
{
    /// <summary>
    /// A <see cref="MonoBehaviour"/> component which automatically detects the <see cref="ObjectPool{T}"/> that
    /// created it so it can be released back to that pool (or simply destroyed if it wasn't created by a pool) using
    /// the <see cref="ObjectPool.TryReleaseOrDestroyGameObject{T}(T)"/> extension method.
    /// <para></para>
    /// When inheriting from this class, <typeparamref name="T"/> should always be the child class itself, I.E.
    /// <code>class ChildClass : PoolableBehaviour&lt;ChildClass&gt;</code>
    /// <para></para>
    /// More detailed instructons on how to use this class and those related to it can be found at
    /// https://kybernetikgames.github.io/weaver/docs/misc/object-pooling.
    /// </summary>
    public abstract class PoolableBehaviour<T> : MonoBehaviour, IPoolable where T : PoolableBehaviour<T>, IPoolable
    {
        /************************************************************************************************************************/

        /// <summary>
        /// The pool that created this object (or null if not created by a pool).
        /// </summary>
        public readonly ObjectPool<T> Pool = ObjectPool.GetCurrentPool<T>();

        /************************************************************************************************************************/

        /// <summary>
        /// Called by the <see cref="Pool"/> when releasing this component to it.
        /// Asserts that the <see cref="Component.gameObject"/> was active and deactivates it (unless overridden).
        /// </summary>
        public virtual void OnRelease()
        {
            Utils.EditorAssert(gameObject.activeSelf,
                "PoolableBehaviour was already inactive when releasing it to the pool: " + this, this);

            gameObject.SetActive(false);
        }

        /************************************************************************************************************************/
#if UNITY_EDITOR
        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Creates a <see cref="CustomInspector"/> on the parent object to draw the pool GUI.</summary>
        protected PoolableBehaviour()
        {
            if (Pool == null ||
                Pool.InactiveObjects.Count != 0 ||
                (Pool.ActiveObjects != null && Pool.ActiveObjects.Count != 0))
                return;

            UnityEditor.EditorApplication.delayCall += () =>
            {
                if (this == null)
                    return;

                var parent = transform.parent;
                if (parent != null && parent.GetComponent<CustomInspector>() == null)
                    CustomInspector.Create(parent.gameObject, Pool, (target) => (target as ObjectPool<T>).DoInspectorGUI);
            };
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Inspector Gadgets GUI event.</summary>
        protected virtual void AfterInspectorGUI()
        {
            GUILayout.BeginVertical(GUI.skin.box);
            {
                if (Pool == null)
                    UnityEditor.EditorGUILayout.LabelField("Pool", "null");
                else
                    Pool.DoInspectorGUI();
            }
            GUILayout.EndVertical();
        }

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
    }
}